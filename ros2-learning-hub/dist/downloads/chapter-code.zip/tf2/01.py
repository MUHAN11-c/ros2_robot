import rclpy
from rclpy.node import Node
from rclpy.time import Time
from geometry_msgs.msg import PointStamped
from tf2_ros import Buffer, TransformListener, TransformException
from tf2_geometry_msgs import do_transform_point

class PointTransformer(Node):
    def __init__(self):
        super().__init__('point_transformer')
        self.buffer = Buffer(node=self)
        self.listener = TransformListener(self.buffer, self)
        self.publisher = self.create_publisher(PointStamped, '/base_point', 10)
        self.subscription = self.create_subscription(
            PointStamped, '/sensor_point', self.receive, 10)

    def receive(self, message):
        if not message.header.frame_id:
            self.get_logger().warning('empty source frame')
            return
        try:
            transform = self.buffer.lookup_transform(
                'base_link', message.header.frame_id,
                Time.from_msg(message.header.stamp))
        except TransformException as error:
            self.get_logger().warning(f'point dropped: {error}')
            return
        result = do_transform_point(message, transform)
        result.header.stamp = message.header.stamp
        self.publisher.publish(result)

def main():
    rclpy.init()
    node = PointTransformer()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()

if __name__ == '__main__':
    main()
