# 【中文教学注释】 point_transform.py 完整文件
# 本例作用：Buffer 保存收到的关系，TransformListener 建立 TF 订阅；Time.from_msg 把输入时间转换为查询类型；do_transform_point 同时计算旋转和平移。异常表示当前无法完成这一坐标请求，不能悄悄把未变换数据标为目标坐标系。
# 输入输出：输入是带 source frame 和采样时间的 PointStamped 及 TF 缓存；输出为 base_link 中的点。
# 执行顺序与边界：平移单位 m、旋转 rad；按输入消息时刻查变换，缺失/外推失败时丢弃并记录。Time(0) 与消息时间不是同一语义，不在单线程回调中长期阻塞等 TF。
import rclpy
from rclpy.node import Node
from rclpy.time import Time
from geometry_msgs.msg import PointStamped
from tf2_ros import Buffer, TransformListener, TransformException
from tf2_geometry_msgs import do_transform_point

class PointTransformer(Node):
    def __init__(self):
        # 构造 Node 基类并确定节点名；后续相对话题/服务名由命名空间解析，重命名需与参数文件选择器对应。
        super().__init__('point_transformer')
        # 创建按时间缓存的 TF 查询器；缓存内容由 TransformListener 接收，创建 Buffer 不会凭空生成变换。
        self.buffer = Buffer(node=self)
        # 订阅 /tf 与 /tf_static 并填充 Buffer，监听器及节点必须保持存活，接收仍需要执行器。
        self.listener = TransformListener(self.buffer, self)
        # 创建指定消息类型和话题的发布端并持久保存；整数 QoS 是 KeepLast 历史深度，不是 Hz，真正发送由 publish 调用决定。
        self.publisher = self.create_publisher(PointStamped, '/base_point', 10)
        # 绑定消息类型、话题、回调和 QoS，并持有订阅对象；/开头的名称是绝对话题，回调由执行器调度。
        self.subscription = self.create_subscription(
            PointStamped, '/sensor_point', self.receive, 10)

    def receive(self, message):
        if not message.header.frame_id:
            # 输出可观测日志用于核对状态；日志成功写出不等于对端收到消息或任务执行成功。
            self.get_logger().warning('empty source frame')
            return
        try:
            # 按目标坐标系、源坐标系和输入消息时刻查变换；方向不能反用，找不到或外推失败会抛 TransformException。
            transform = self.buffer.lookup_transform(
                'base_link', message.header.frame_id,
                # 把消息采样时间转换为查询所需 Time；这是测量时刻，不能任意改成回调接收时刻。
                Time.from_msg(message.header.stamp))
        except TransformException as error:
            self.get_logger().warning(f'point dropped: {error}')
            return
        # 对点应用查询到的旋转与平移，坐标单位 m；先保证 transform 对应正确源/目标和采样时刻。
        result = do_transform_point(message, transform)
        result.header.stamp = message.header.stamp
        # 提交已填好的消息给 ROS 发布端；这不是业务处理完成确认，端到端接收仍取决于发现、类型、QoS 和执行器。
        self.publisher.publish(result)

# 程序入口按本章顺序组织资源；本例仅在 __main__ 下运行，import 时不应启动节点或连接硬件。
def main():
    # 初始化当前进程的 ROS 上下文并解析传入 ROS 参数；在创建节点/端点之前调用。
    rclpy.init()
    node = PointTransformer()
    try:
        # 进入执行器事件循环，定时器、订阅、服务和 Future 回调在这里才被推进；通常阻塞到中断或上下文关闭。
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        # 显式释放节点所属端点与定时器；应在相关执行器不再访问节点后执行。
        node.destroy_node()
        # 检查 ROS 上下文仍有效，避免退出流程重复 shutdown；它不表示节点业务健康。
        if rclpy.ok():
            # 关闭本进程 ROS 上下文；先停止执行器、销毁端点/节点，再在上下文仍有效时调用。
            rclpy.shutdown()

if __name__ == '__main__':
    main()