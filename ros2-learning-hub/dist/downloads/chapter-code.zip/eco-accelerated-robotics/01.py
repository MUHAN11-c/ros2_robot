def percentile(values, q):
    values = sorted(values)
    position = (len(values) - 1) * q
    lower = int(position)
    upper = min(lower + 1, len(values) - 1)
    weight = position - lower
    return values[lower] * (1 - weight) + values[upper] * weight

cpu_ms = [2 + 12 + x for x in [1, 2, 1, 3, 2]]
gpu_ms = [4 + 3 + 4 + x for x in [1, 2, 8, 12, 20]]
for name, samples in [("cpu", cpu_ms), ("gpu", gpu_ms)]:
    print(name, "median", percentile(samples, 0.5), "p95", percentile(samples, 0.95))
