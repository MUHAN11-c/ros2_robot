# 【中文教学注释】 latency_model.py：完整离线分析实验
# 本例作用：数值是教学假设；程序未在本次执行。GPU 计算项更小，但排队波动会增加尾部延迟。
# 输入输出：输入为假设的 CPU/GPU 各环节时延或 ROS 感知数据；输出为中位数和尾部分位数。
# 执行顺序与边界：合成时延单位 ms，q 无量纲且应在 [0,1]；数组必须非空。GPU 计算快不保证端到端尾延迟低，结果不是硬件测速。
# 分位数输入需非空，q在[0,1]；本例使用线性插值，不能与另一段nearest-rank实现混为同一统计定义。
def percentile(values, q):
    values = sorted(values)
    position = (len(values) - 1) * q
    lower = int(position)
    upper = min(lower + 1, len(values) - 1)
    weight = position - lower
    return values[lower] * (1 - weight) + values[upper] * weight

cpu_ms = [2 + 12 + x for x in [1, 2, 1, 3, 2]]
gpu_ms = [4 + 3 + 4 + x for x in [1, 2, 8, 12, 20]]
for name, samples in [("cpu", cpu_ms), ("gpu", gpu_ms)]:
    print(name, "median", percentile(samples, 0.5), "p95", percentile(samples, 0.95))