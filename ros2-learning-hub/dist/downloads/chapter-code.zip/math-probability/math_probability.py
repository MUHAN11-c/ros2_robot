#!/usr/bin/env python3
"""输入：已知概率及独立测量方差；输出：后验概率、融合值与相关性反例。"""

def run():
    import math
    import random

    def binary_posterior(prior, hit_rate, false_alarm):
        # 三个输入都是 [0,1] 内的无量纲概率；分母为零表示事件不可能发生。
        if not all(0.0 <= p <= 1.0 for p in (prior, hit_rate, false_alarm)):
            raise ValueError('概率必须在 [0,1] 内')
        evidence = prior * hit_rate + (1.0-prior) * false_alarm
        if evidence <= 0.0:
            raise ValueError('观测事件概率为零，不能条件化')
        return prior * hit_rate / evidence

    posterior = binary_posterior(0.2, 0.9, 0.1)
    assert math.isclose(posterior, 9.0/13.0, abs_tol=1e-12)
    try:
        binary_posterior(0.5, 0.0, 0.0)
    except ValueError:
        pass
    else:
        raise AssertionError('零证据事件本应被拒绝')

    # 两个传感器独立观测同一静止位置：米、平方米；采用平坦先验。
    measurements_m = [2.0, 2.6]
    variances_m2 = [0.04, 0.16]
    precisions = [1.0/value for value in variances_m2]
    posterior_variance = 1.0 / sum(precisions)
    posterior_mean = posterior_variance * sum(z*w for z, w in zip(measurements_m, precisions))
    assert math.isclose(posterior_mean, 2.12, abs_tol=1e-12)
    assert math.isclose(posterior_variance, 0.032, abs_tol=1e-12)

    # 有限样本计算证明：零协方差不蕴含独立。Y=X^2 完全由 X 决定。
    x_values = [-1.0, 0.0, 1.0]
    y_values = [x*x for x in x_values]
    mean_x, mean_y = sum(x_values)/3.0, sum(y_values)/3.0
    covariance = sum((x-mean_x)*(y-mean_y) for x, y in zip(x_values, y_values))/3.0
    assert math.isclose(covariance, 0.0, abs_tol=1e-12)
    assert y_values[1] == 0.0 and y_values[0] == 1.0

    # 固定随机种子，使采样实验可复现；容差是该固定样本的验收界限。
    # 不能把一次采样通过解释成分布、独立性或传感器质量的证明。
    generator = random.Random(20261107)
    samples = [generator.gauss(2.0, 0.2) for _ in range(30000)]
    sample_mean = sum(samples)/len(samples)
    sample_variance = sum((v-sample_mean)**2 for v in samples)/(len(samples)-1)
    assert abs(sample_mean-2.0) < 0.01
    assert abs(sample_variance-0.04) < 0.002
    result = {'posterior_inside': posterior, 'fused_position_m': posterior_mean,
              'fused_variance_m2': posterior_variance, 'sample_mean_m': sample_mean,
              'sample_variance_m2': sample_variance}
    print('概率与测量实验通过：', result)
    return result

if __name__ == '__main__':
    run()
