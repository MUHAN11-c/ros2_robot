#!/usr/bin/env bash
# 输入：可信的ROS/应用setup脚本与命令argv；两个绝对前缀是Dockerfile内约定。
# 输出：exec目标的stdout/stderr和退出状态；不构建镜像或产生归档摘要。
# 顺序：启用错误退出→加载ROS underlay→加载应用overlay→替换当前shell。
# source末尾的--传给setup脚本，避免它把应用argv当作自身选项；返回后原argv保留。
set -e
source /opt/ros/jazzy/setup.bash --
source /work/install/setup.bash --
# exec只替换成指定命令；默认CMD直接到节点，自定义包装器的信号合同需另验收。
# Docker构建/停机未运行，宿主source+exec正例的范围独立记录。
exec "$@"
