#!/usr/bin/env bash
set -e
source /opt/ros/jazzy/setup.bash
source /work/install/setup.bash
exec "$@"
