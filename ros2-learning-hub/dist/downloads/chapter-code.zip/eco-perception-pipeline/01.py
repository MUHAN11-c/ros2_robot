import cv2
import numpy as np
import rclpy
from rclpy.node import Node
from rclpy.qos import qos_profile_sensor_data
from sensor_msgs.msg import Image
from cv_bridge import CvBridge

class ImageLab(Node):
    def __init__(self):
        super().__init__("image_lab")
        self.bridge = CvBridge()
        self.raw_pub = self.create_publisher(Image, "/camera/image_raw", qos_profile_sensor_data)
        self.edge_pub = self.create_publisher(Image, "/camera/edges", qos_profile_sensor_data)
        self.sub = self.create_subscription(Image, "/camera/image_raw", self.process, qos_profile_sensor_data)
        self.timer = self.create_timer(0.1, self.generate)

    def generate(self):
        frame = np.zeros((240, 320, 3), dtype=np.uint8)
        cv2.rectangle(frame, (80, 60), (240, 180), (255, 255, 255), 3)
        msg = self.bridge.cv2_to_imgmsg(frame, encoding="bgr8")
        msg.header.stamp = self.get_clock().now().to_msg()
        msg.header.frame_id = "camera_optical_frame"
        self.raw_pub.publish(msg)

    def process(self, msg):
        frame = self.bridge.imgmsg_to_cv2(msg, desired_encoding="bgr8")
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        edges = cv2.Canny(gray, 50, 150)
        output = self.bridge.cv2_to_imgmsg(edges, encoding="mono8")
        output.header = msg.header
        self.edge_pub.publish(output)

def main():
    rclpy.init()
    node = ImageLab()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()

if __name__ == "__main__":
    main()
