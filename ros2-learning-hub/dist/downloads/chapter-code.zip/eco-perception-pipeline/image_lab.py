# 【中文教学注释】 image_lab.py
# 本例作用：处理结果保留输入 header；没有把处理完成时间冒充原始采样时间。
# 输入输出：输入为合成像素图像或 ROS Image；输出为原图和边缘图话题。
# 执行顺序与边界：图像尺寸以像素计，颜色 bgr8/mono8 为编码；生成周期 0.1 s。处理保留原采样 Header，转换不等于相机已标定或图像已同步。
import cv2
import numpy as np
import rclpy
from rclpy.node import Node
# 使用传感器 QoS 预设；关键是低积压和 best-effort 语义，双方仍需检查具体策略。
from rclpy.qos import qos_profile_sensor_data
from sensor_msgs.msg import Image
from cv_bridge import CvBridge

class ImageLab(Node):
    def __init__(self):
        # 构造 Node 基类并确定节点名；后续相对话题/服务名由命名空间解析，重命名需与参数文件选择器对应。
        super().__init__("image_lab")
        self.bridge = CvBridge()
        # 创建指定消息类型和话题的发布端并持久保存；整数 QoS 是 KeepLast 历史深度，不是 Hz，真正发送由 publish 调用决定。
        self.raw_pub = self.create_publisher(Image, "/camera/image_raw", qos_profile_sensor_data)
        self.edge_pub = self.create_publisher(Image, "/camera/edges", qos_profile_sensor_data)
        # 绑定消息类型、话题、回调和 QoS，并持有订阅对象；/开头的名称是绝对话题，回调由执行器调度。
        self.sub = self.create_subscription(Image, "/camera/image_raw", self.process, qos_profile_sensor_data)
        # 定时周期单位为秒，回调由执行器调度而非自动新建独占线程；使用节点时钟，仿真时间暂停可能影响触发。
        self.timer = self.create_timer(0.1, self.generate)

    def generate(self):
        # 创建 height×width×channels 的 uint8 图像，尺寸是像素；本例全零黑底，不来自实际相机。
        frame = np.zeros((240, 320, 3), dtype=np.uint8)
        # 按像素坐标绘制白色矩形，颜色顺序是 BGR，最后一个数是线宽像素。
        cv2.rectangle(frame, (80, 60), (240, 180), (255, 255, 255), 3)
        # 将 OpenCV 数组按指定 bgr8/mono8 编码转为 ROS Image；随后须正确设置或保留采样 Header。
        msg = self.bridge.cv2_to_imgmsg(frame, encoding="bgr8")
        # 取得节点当前 ROS 时刻并转换为 sec/nanosec 消息；use_sim_time 时来自 /clock，采样时刻应尽量靠近数据生成。
        msg.header.stamp = self.get_clock().now().to_msg()
        # 坐标系名称是离散标识；它必须与数值实际表达的坐标系相符，改字符串不会完成坐标变换。
        msg.header.frame_id = "camera_optical_frame"
        # 提交已填好的消息给 ROS 发布端；这不是业务处理完成确认，端到端接收仍取决于发现、类型、QoS 和执行器。
        self.raw_pub.publish(msg)

    def process(self, msg):
        # 按 desired_encoding 解释图像字节，编码不匹配可能转换或报错；不能只依据数组形状猜测颜色顺序。
        frame = self.bridge.imgmsg_to_cv2(msg, desired_encoding="bgr8")
        # 按明确的 BGR→灰度规则转换像素，避免将 RGB/BGR 顺序混淆；这不进行相机几何校准。
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        # Canny 的50/150是梯度阈值，不是距离或置信概率；输出为单通道8位边缘图。
        edges = cv2.Canny(gray, 50, 150)
        output = self.bridge.cv2_to_imgmsg(edges, encoding="mono8")
        # 处理结果沿用原始采样时刻与坐标系，不能把回调完成时刻冒充相机曝光时刻。
        output.header = msg.header
        self.edge_pub.publish(output)

# 程序入口按本章顺序组织资源；本例仅在 __main__ 下运行，import 时不应启动节点或连接硬件。
def main():
    # 初始化当前进程的 ROS 上下文并解析传入 ROS 参数；在创建节点/端点之前调用。
    rclpy.init()
    node = ImageLab()
    try:
        # 进入执行器事件循环，定时器、订阅、服务和 Future 回调在这里才被推进；通常阻塞到中断或上下文关闭。
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        # 显式释放节点所属端点与定时器；应在相关执行器不再访问节点后执行。
        node.destroy_node()
        # 检查 ROS 上下文仍有效，避免退出流程重复 shutdown；它不表示节点业务健康。
        if rclpy.ok():
            # 关闭本进程 ROS 上下文；先停止执行器、销毁端点/节点，再在上下文仍有效时调用。
            rclpy.shutdown()

if __name__ == "__main__":
    main()