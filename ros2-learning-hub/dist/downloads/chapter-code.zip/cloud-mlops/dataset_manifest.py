# 【中文教学注释】 dataset_manifest.py
# 本例作用：完整只读目录清单工具。输出写到标准输出，由调用者决定保存位置。
# 输入输出：输入为只读数据目录；输出为相对路径、字节数与 SHA256 的确定性 JSON 清单。
# 执行顺序与边界：按路径排序并分块哈希，不修改原数据；软链接必须有独立策略。摘要证明字节一致性，不证明标签、校准或训练划分正确。
"""Create a deterministic manifest on stdout. Input data is never modified."""
import hashlib
import json
import sys
from pathlib import Path

# 只读扫描真实数据目录，输出按路径排序的文件条目；大小单位为字节，遇软链接按本示例策略拒绝。
def manifest(root):
    root = Path(root).resolve(strict=True)
    if not root.is_dir():
        raise ValueError("dataset root must be a directory")
    files = []
    for path in sorted(root.rglob("*")):
        # 本实验拒绝软链接，以免扫描越过数据集边界；需要链接时必须先定义明确的数据归属策略。
        if path.is_symlink():
            raise ValueError("symbolic links require an explicit data policy")
        if not path.is_file():
            continue
        # 建立 SHA256 摘要器，随后逐块更新；摘要只验证字节内容一致，不提供数据语义或标注正确性证明。
        digest = hashlib.sha256()
        with path.open("rb") as stream:
            for block in iter(lambda: stream.read(1024 * 1024), b""):
                # 按读取顺序累计原始字节摘要；不把路径或文本编码替代文件实际字节。
                digest.update(block)
        files.append({"path": path.relative_to(root).as_posix(),
                      "bytes": path.stat().st_size, "sha256": digest.hexdigest()})
    return {"schema": 1, "files": files}

if __name__ == "__main__":
    if len(sys.argv) != 2:
        raise SystemExit("usage: python3 dataset_manifest.py DATA_DIRECTORY")
    print(json.dumps(manifest(sys.argv[1]), ensure_ascii=False, indent=2))
