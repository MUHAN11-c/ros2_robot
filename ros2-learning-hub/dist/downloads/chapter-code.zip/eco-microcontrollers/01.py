def accepted_target(now, received_at, requested, timeout=0.3):
    if received_at is None:
        return 0.0
    age = now - received_at
    if age < 0 or age > timeout:
        return 0.0
    return max(-0.2, min(0.2, requested))

assert accepted_target(1.0, None, 0.1) == 0.0
assert accepted_target(1.1, 1.0, 0.1) == 0.1
assert accepted_target(1.5, 1.0, 0.1) == 0.0
assert accepted_target(1.1, 1.0, 0.8) == 0.2
print("watchdog model checks passed")
