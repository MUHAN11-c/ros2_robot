def slam_lab():
    """求解固定第一帧的一维位姿图，并检验未固定时的平移规范自由度。"""
    from math import isclose

    # 输入：相邻位移 z01=z12=1.1 m，回环位移 z02=2.0 m；相同方差可约掉。
    # 固定 x0=0 后，最小化 (x1-1.1)^2+(x2-x1-1.1)^2+(x2-2.0)^2。
    h00, h01, h11 = 2.0, -1.0, 2.0
    b0, b1 = 0.0, 3.1
    determinant = h00*h11 - h01*h01
    assert determinant > 0.0  # 这个带锚点的小问题有唯一解。
    x1 = (h11*b0 - h01*b1) / determinant
    x2 = (-h01*b0 + h00*b1) / determinant

    def cost(a, b):
        return (a-1.1)**2 + (b-a-1.1)**2 + (b-2.0)**2

    assert isclose(x1, 1.0333333333333334)
    assert isclose(x2, 2.066666666666667)
    assert cost(x1, x2) < cost(1.1, 2.2)
    # 未锚定的三节点拉普拉斯矩阵乘全一向量为零：整体平移不改变相对残差。
    h_free = ((2,-1,-1), (-1,2,-1), (-1,-1,2))
    assert all(sum(row) == 0 for row in h_free)
    residuals = (x1-1.1, x2-x1-1.1, x2-2.0)
    # 在该一维线性模型中，梯度 J^T r 应为零；不等于每条测量都完全满足。
    assert abs(residuals[0]-residuals[1]) < 1e-12
    assert abs(residuals[1]+residuals[2]) < 1e-12
    result = {"x1_m": x1, "x2_m": x2, "优化前代价_m2": cost(1.1,2.2),
              "优化后代价_m2": cost(x1,x2)}
    print("一维位姿图", result)
    return result

if __name__ == "__main__":
    slam_lab()
