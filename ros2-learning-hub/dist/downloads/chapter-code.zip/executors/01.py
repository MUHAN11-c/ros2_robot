import time
import rclpy
from rclpy.node import Node
from example_interfaces.srv import AddTwoInts

class AsyncPoll(Node):
    def __init__(self):
        super().__init__('async_poll')
        self.client = self.create_client(AddTwoInts, 'add_two_ints')
        self.pending = None
        self.sent_at = 0.0
        self.timer = self.create_timer(0.2, self.tick)

    def tick(self):
        if self.pending is not None:
            if self.pending.done():
                try:
                    result = self.pending.result()
                    self.get_logger().info(f'sum={result.sum}')
                except Exception as error:
                    self.get_logger().error(str(error))
                self.pending = None
            elif time.monotonic() - self.sent_at > 2.0:
                self.client.remove_pending_request(self.pending)
                self.get_logger().warning('response timeout')
                self.pending = None
            return
        if not self.client.service_is_ready():
            return
        request = AddTwoInts.Request()
        request.a = 7
        request.b = 5
        self.sent_at = time.monotonic()
        self.pending = self.client.call_async(request)

def main():
    rclpy.init()
    node = AsyncPoll()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()

if __name__ == '__main__':
    main()
