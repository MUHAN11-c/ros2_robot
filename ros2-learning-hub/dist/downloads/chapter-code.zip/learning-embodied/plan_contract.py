# 【中文教学注释】 plan_contract.py
# 本例作用：完整离线计划校验器；只预览任务，不执行模型生成的代码，不启动机器人。
# 输入输出：输入为 JSON 任务提案和地点/技能白名单；输出为 DRY_RUN 或拒绝原因。
# 执行顺序与边界：计划限 1..8 步，timeout 为有限秒值且 0<值≤120；先做结构和字段验证，再演示计划，不执行 shell、ROS 或真实动作。
"""Validate a task proposal and print a dry-run; never executes ROS commands."""
import json
import math

# 地点ID映射到预先认可的map位姿；x/y为m、yaw为rad，模型生成的任意坐标不直接获得执行授权。
PLACES = {"desk": (1.0, 0.5, 0.0), "dock": (0.0, 0.0, 0.0)}

# 先校验类型、字段集合与数值边界，再返回计划/参数验证结果；通过校验不表示环境或动作执行一定成功。
def validate(raw):
    # 把 JSON 文本解析为数据，不执行其中内容；解析成功后仍必须校验类型、字段、白名单和数值范围。
    plan = json.loads(raw)
    if not isinstance(plan, list) or not 1 <= len(plan) <= 8:
        raise ValueError("plan must contain 1..8 steps")
    for step in plan:
        if not isinstance(step, dict):
            raise ValueError("step must be an object")
        skill = step.get("skill")
        # 白名单明确每种技能的完整允许字段集合，不能把自然语言或额外shell字段直接转换为可执行动作。
        allowed = {"navigate": {"skill", "place", "timeout"},
                   "inspect": {"skill", "object", "timeout"}}
        if not isinstance(skill, str) or skill not in allowed or set(step) != allowed[skill]:
            raise ValueError("unknown skill or unexpected fields")
        timeout = step["timeout"]
        # 显式拒绝bool、NaN、Inf及越界时长；Python中bool是int子类，因此这里检查具体type而非宽泛isinstance。
        if type(timeout) not in (int, float) or not math.isfinite(timeout) or not 0 < timeout <= 120:
            raise ValueError("invalid timeout")
        if skill == "navigate" and (not isinstance(step["place"], str) or step["place"] not in PLACES):
            raise ValueError("unknown place")
        if skill == "inspect" and step["object"] not in ("cup", "marker"):
            raise ValueError("unsupported object")
    return plan

# 程序入口按本章顺序组织资源；本例仅在 __main__ 下运行，import 时不应启动节点或连接硬件。
def main():
    sample = '[{"skill":"navigate","place":"desk","timeout":60},{"skill":"inspect","object":"cup","timeout":10}]'
    for index, step in enumerate(validate(sample), 1):
        print("DRY_RUN", index, step)
    for bad in ('[{"skill":"shell","command":"anything","timeout":10}]',
                '[{"skill":"navigate","place":"unknown","timeout":60}]'):
        try:
            validate(bad)
        except ValueError as error:
            print("REJECTED", error)
        else:
            raise AssertionError("invalid plan accepted")

if __name__ == "__main__":
    main()
