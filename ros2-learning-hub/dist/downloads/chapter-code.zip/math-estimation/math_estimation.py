#!/usr/bin/env python3
"""输入：位置/速度先验与一次位置观测；输出：Kalman 更新、协方差和新息门限。"""

def run():
    import math

    def transpose(a):
        return [list(row) for row in zip(*a)]

    def multiply(a, b):
        # 只用于本例的小矩阵；尺寸必须满足 A 的列数等于 B 的行数。
        assert len(a[0]) == len(b)
        return [[sum(x*y for x, y in zip(row, column)) for column in zip(*b)] for row in a]

    def add(a, b):
        return [[x+y for x, y in zip(ra, rb)] for ra, rb in zip(a, b)]

    # x=[位置(m),速度(m/s)]；dt 单位 s；一次采样内未知加速度恒定。
    dt = 1.0
    state = [0.0, 1.0]
    covariance = [[0.04, 0.0], [0.0, 0.01]]
    transition = [[1.0, dt], [0.0, 1.0]]
    sigma_acceleration = 0.1  # m/s^2；这不是连续白噪声的谱密度。
    input_column = [0.5*dt*dt, dt]
    process_covariance = [[sigma_acceleration**2*a*b for b in input_column] for a in input_column]
    predicted_state = [state[0]+dt*state[1], state[1]]
    predicted_covariance = add(multiply(multiply(transition, covariance), transpose(transition)),
                               process_covariance)
    assert math.isclose(predicted_covariance[0][0], 0.0525, abs_tol=1e-12)

    # H=[1,0] 只测位置；R 必须是方差 m^2，不能误填标准差 0.2m。
    measured_position, measurement_variance = 1.2, 0.04
    innovation = measured_position-predicted_state[0]
    innovation_variance = predicted_covariance[0][0]+measurement_variance
    assert innovation_variance > 0.0
    gain = [predicted_covariance[i][0]/innovation_variance for i in range(2)]
    corrected_state = [x+k*innovation for x, k in zip(predicted_state, gain)]

    # Joseph 形式：P+=(I-KH)P-(I-KH)^T+KRK^T，较直接减法更便于保留正定性。
    identity_minus_kh = [[1.0-gain[0], 0.0], [-gain[1], 1.0]]
    corrected_covariance = add(
        multiply(multiply(identity_minus_kh, predicted_covariance), transpose(identity_minus_kh)),
        [[measurement_variance*a*b for b in gain] for a in gain])
    simplified = multiply(identity_minus_kh, predicted_covariance)
    assert max(abs(a-b) for ra, rb in zip(corrected_covariance, simplified) for a, b in zip(ra, rb)) < 1e-12
    assert abs(corrected_covariance[0][1]-corrected_covariance[1][0]) < 1e-12
    assert corrected_covariance[0][0]*corrected_covariance[1][1]-corrected_covariance[0][1]**2 > 0.0
    assert math.isclose(corrected_state[0], 1.1135135135135135, abs_tol=1e-12)
    # 同一个位置后验也能通过“先验精度+测量精度”计算，独立核对位置分量。
    scalar_variance = 1.0/(1.0/predicted_covariance[0][0]+1.0/measurement_variance)
    scalar_mean = scalar_variance*(predicted_state[0]/predicted_covariance[0][0]
                                   + measured_position/measurement_variance)
    assert math.isclose(corrected_state[0], scalar_mean, abs_tol=1e-12)

    # 无量纲 NIS：一维正确线性高斯模型下，门限 9 对应约三倍标准差。
    nis = innovation**2/innovation_variance
    outlier_nis = (100.0-predicted_state[0])**2/innovation_variance
    assert nis < 9.0 and outlier_nis > 9.0
    # 两次位置测量的可观性矩阵 [[1,0],[1,dt]] 在 dt!=0 时满秩。
    assert dt != 0.0
    result = {'predicted_state': predicted_state, 'gain': gain, 'corrected_state': corrected_state,
              'corrected_covariance': corrected_covariance, 'NIS': nis}
    print('状态估计实验通过：', result)
    return result

if __name__ == '__main__':
    run()
