def optimal_control_lab():
    """有限时域标量 LQR；验证 Riccati 值函数与直接累计代价一致。"""
    from math import isclose

    # 输入：x 为位置/1 m，u 为速度/(1 m/s)，均无量纲；b=采样周期 0.1 s。
    a, b, q, r, terminal, horizon = 1.0, 0.1, 1.0, 0.1, 5.0, 20
    assert r > 0 and q >= 0 and terminal >= 0
    p = [0.0]*(horizon+1)
    gains = [0.0]*horizon
    p[horizon] = terminal
    # 顺序一：从终点向起点回推，与随后正向运行的顺序相反。
    for k in range(horizon-1,-1,-1):
        denominator = r+b*b*p[k+1]
        gains[k] = a*b*p[k+1]/denominator
        p[k] = q+a*a*p[k+1]-(a*b*p[k+1])**2/denominator
        assert p[k] >= 0
    # 顺序二：只在无约束模型里使用精确最优反馈，不把裁剪输入称为约束最优解。
    x, x0, total = 2.0, 2.0, 0.0
    first_u = None
    for k,gain in enumerate(gains):
        u = -gain*x
        first_u = u if k == 0 else first_u
        total += q*x*x+r*u*u
        x = a*x+b*u
    total += terminal*x*x
    assert isclose(total,p[0]*x0*x0,rel_tol=1e-12)
    zero_input_cost = (horizon*q+terminal)*x0*x0
    assert total < zero_input_cost and abs(x) < abs(x0)
    result = {"初始最优速度_m_s": first_u, "末端位置_m": x,
              "最优代价": total, "零输入代价": zero_input_cost}
    print("有限时域 LQR", result)
    return result

if __name__ == "__main__":
    optimal_control_lab()
