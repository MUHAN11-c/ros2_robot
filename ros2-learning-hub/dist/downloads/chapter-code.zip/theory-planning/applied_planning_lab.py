def planning_lab():
    """在四邻接、单位正代价、点机器人模型中比较 A* 与 Dijkstra。"""
    import heapq

    width, height, resolution_m = 7, 5, 0.1
    start, goal = (0,0), (6,0)
    walls = {(3,y) for y in range(4)}  # 顶部 y=4 留一个通道。

    def search(obstacles, use_heuristic):
        # g 的单位是格数；启发式是到目标的曼哈顿格数，与四邻接模型一致。
        def heuristic(p):
            return abs(p[0]-goal[0])+abs(p[1]-goal[1]) if use_heuristic else 0
        if start in obstacles or goal in obstacles:
            return None
        heap = [(heuristic(start),0,start)]
        distance, previous = {start:0}, {}
        while heap:
            _, g, current = heapq.heappop(heap)
            if g != distance.get(current):
                continue  # 跳过已被更短路径取代的旧队列项。
            if current == goal:
                path = [goal]
                while path[-1] != start:
                    path.append(previous[path[-1]])
                return list(reversed(path))
            for dx,dy in ((1,0),(-1,0),(0,1),(0,-1)):
                nxt = current[0]+dx, current[1]+dy
                if not (0 <= nxt[0] < width and 0 <= nxt[1] < height):
                    continue
                if nxt in obstacles:
                    continue
                new_g = g+1
                if new_g < distance.get(nxt,float("inf")):
                    distance[nxt], previous[nxt] = new_g,current
                    heapq.heappush(heap,(new_g+heuristic(nxt),new_g,nxt))
        return None  # 队列耗尽是明确的无路结果，不能继续执行旧路径。

    path_a = search(walls,True)
    path_d = search(walls,False)
    assert path_a is not None and path_d is not None
    assert len(path_a)-1 == len(path_d)-1 == 14
    assert all(p not in walls for p in path_a)
    assert all(abs(a[0]-b[0])+abs(a[1]-b[1]) == 1 for a,b in zip(path_a,path_a[1:]))
    assert search(walls | {(3,4)},True) is None
    result = {"最优步数": len(path_a)-1, "路径长度_m": (len(path_a)-1)*resolution_m,
              "封闭通道结果": "无路"}
    print("网格搜索", result)
    return result

if __name__ == "__main__":
    planning_lab()
