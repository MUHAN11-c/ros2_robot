#!/usr/bin/env python3
"""输入：固定非线性残差与异常测量；输出：阻尼迭代、约束解和鲁棒估计。"""

def run():
    import math

    def residual(x):
        return x*x-4.0  # 教学无量纲残差，正根为 2，负根为 -2。

    def objective(x):
        return 0.5*residual(x)**2

    # 用中心差分独立核对解析梯度；h 是无量纲状态扰动。
    point, h = 1.3, 1e-6
    numerical_gradient = (objective(point+h)-objective(point-h))/(2*h)
    analytical_gradient = 2*point*residual(point)
    assert abs(numerical_gradient-analytical_gradient) < 1e-6

    # 一维 LM 风格演示：先提候选步，再用真实目标值决定接受与否。
    # 实际求解器通常使用更完整的信赖域增益比和尺度处理。
    x, damping = 1.0, 0.1
    accepted_costs = [objective(x)]
    for _ in range(60):
        r, jacobian = residual(x), 2*x
        if abs(r) < 1e-10:
            break
        delta = -jacobian*r/(jacobian*jacobian+damping)
        candidate = min(5.0, max(0.1, x+delta))  # 显式选择正根分支的状态范围。
        if objective(candidate) < objective(x):
            x = candidate
            damping = max(1e-12, damping/3.0)
            accepted_costs.append(objective(x))
        else:
            damping *= 10.0
    assert abs(x-2.0) < 1e-8
    assert all(a > b for a, b in zip(accepted_costs, accepted_costs[1:]))
    # x=0 的梯度为零，增加阻尼并不能自动摆脱这个非最优驻点。
    assert 2*0.0*residual(0.0) == 0.0 and objective(0.0) > objective(2.0)

    # 投影梯度：最小化 0.5*(x-3)^2，约束 [-1,1]；最优点位于上边界。
    constrained = 0.0
    for _ in range(30):
        constrained = min(1.0, max(-1.0, constrained-0.5*(constrained-3.0)))
    assert constrained == 1.0
    multiplier = 3.0-constrained
    assert math.isclose((constrained-3.0)+multiplier, 0.0, abs_tol=1e-12)

    # Huber 损失：delta=1m；这里已把测量按 1m 参考尺度无量纲化。
    measurements = [2.0, 2.1, 1.9, 20.0]
    ordinary_mean = sum(measurements)/len(measurements)
    robust = 2.0
    for _ in range(150):
        gradient = sum(max(-1.0, min(1.0, robust-z)) for z in measurements)
        robust -= 0.2*gradient
    assert math.isclose(robust, 7.0/3.0, abs_tol=1e-8)
    assert ordinary_mean == 6.5 and abs(robust-2.0) < abs(ordinary_mean-2.0)
    result = {'nonlinear_positive_root': x, 'accepted_costs': accepted_costs,
              'constrained_solution': constrained, 'L2_mean': ordinary_mean, 'Huber_estimate': robust}
    print('优化实验通过：', result)
    return result

if __name__ == '__main__':
    run()
