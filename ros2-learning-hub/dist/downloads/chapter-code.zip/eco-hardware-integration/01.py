import struct

def encode_speed(speed_m_s):
    raw = round(speed_m_s * 1000)
    if not -32768 <= raw <= 32767:
        raise ValueError("speed out of range")
    return struct.pack("<h", raw)

def decode_status(payload):
    if len(payload) != 3:
        raise ValueError("expected three bytes")
    speed_raw, temperature = struct.unpack("<hb", payload)
    return speed_raw / 1000.0, temperature

if __name__ == "__main__":
    assert encode_speed(-0.25) == bytes([6, 255])
    assert decode_status(bytes([250, 0, 30])) == (0.25, 30)
    print("teaching protocol checks passed")
