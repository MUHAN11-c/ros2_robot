# 【中文教学注释】 protocol_check.py：完整的离线编码实验
# 本例作用：这是完整可运行的纯 Python 教学程序，未在本次文档编写时执行；不存在任何实机写入操作。
# 输入输出：输入为教学协议的速度/字节串或已配置设备的观测数据；输出为编码字节和解码后的状态。
# 执行顺序与边界：速度 m/s 乘 1000 编成 mm/s int16，小端且溢出拒绝；示例没有厂商协议兼容承诺，CAN/串口命令需对应实际配置，不在此处发硬件运动命令。
import struct

# 输入 speed_m_s 为 m/s；先缩放、取整并检查int16范围，输出两个小端字节。
def encode_speed(speed_m_s):
    # 速度m/s放大1000成为mm/s整数；round引入量化，发送前还须检查有符号int16的可表示范围。
    raw = round(speed_m_s * 1000)
    if not -32768 <= raw <= 32767:
        raise ValueError("speed out of range")
    # 按 <h 编成小端有符号 int16；先将 m/s 放大为 mm/s 并检查 [-32768,32767]，不能静默溢出。
    return struct.pack("<h", raw)

# 输入恰为3字节；输出 (速度m/s, 教学协议温度整数)，不是某厂商报文的通用解码器。
def decode_status(payload):
    # 先检查精确报文长度再按协议字段解包；不能把截断或额外字节默默解释成有效状态。
    if len(payload) != 3:
        raise ValueError("expected three bytes")
    # 按 <hb 读取小端 int16 速度和有符号 int8 温度；输入必须恰为3字节，速度随后除1000还原 m/s。
    speed_raw, temperature = struct.unpack("<hb", payload)
    return speed_raw / 1000.0, temperature

if __name__ == "__main__":
    # 断言检验本例明确的数值/边界性质；失败立即暴露问题，不能用这里的合成样本证明所有输入或实机安全。
    assert encode_speed(-0.25) == bytes([6, 255])
    assert decode_status(bytes([250, 0, 30])) == (0.25, 30)
    print("teaching protocol checks passed")