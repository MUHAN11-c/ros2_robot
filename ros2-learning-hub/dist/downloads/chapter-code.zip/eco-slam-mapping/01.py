import math
import rclpy
from rclpy.node import Node
from rclpy.qos import qos_profile_sensor_data
from sensor_msgs.msg import LaserScan

class SquareScan(Node):
    def __init__(self):
        super().__init__("square_scan")
        self.pub = self.create_publisher(LaserScan, "/scan", qos_profile_sensor_data)
        self.timer = self.create_timer(0.1, self.publish_scan)

    def publish_scan(self):
        msg = LaserScan()
        msg.header.stamp = self.get_clock().now().to_msg()
        msg.header.frame_id = "laser"
        msg.angle_min = -math.pi
        msg.angle_increment = 2.0 * math.pi / 360.0
        msg.angle_max = msg.angle_min + 359 * msg.angle_increment
        msg.range_min = 0.05
        msg.range_max = 10.0
        msg.scan_time = 0.1
        for i in range(360):
            a = msg.angle_min + i * msg.angle_increment
            distance = min(2.0 / max(abs(math.cos(a)), 1e-9),
                           2.0 / max(abs(math.sin(a)), 1e-9))
            msg.ranges.append(distance)
        self.pub.publish(msg)

def main():
    rclpy.init()
    node = SquareScan()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()

if __name__ == "__main__":
    main()
