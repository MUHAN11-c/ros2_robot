# 【中文教学注释】 square_scan.py：完整合成传感器
# 本例作用：该节点没有运动控制功能，仅发布合成扫描。
# 输入输出：输入为 LaserScan、TF、时钟与建图参数；输出为合成扫描、地图和保存文件。
# 执行顺序与边界：距离 m、角度 rad、栅格分辨率 m/cell；合成方房间只是数据契约实验，没有真实运动或 SLAM 精度证明。保存前检查 TF 和扫描时间。
import math
import rclpy
from rclpy.node import Node
# 使用传感器 QoS 预设；关键是低积压和 best-effort 语义，双方仍需检查具体策略。
from rclpy.qos import qos_profile_sensor_data
from sensor_msgs.msg import LaserScan

class SquareScan(Node):
    def __init__(self):
        # 构造 Node 基类并确定节点名；后续相对话题/服务名由命名空间解析，重命名需与参数文件选择器对应。
        super().__init__("square_scan")
        # 创建指定消息类型和话题的发布端并持久保存；整数 QoS 是 KeepLast 历史深度，不是 Hz，真正发送由 publish 调用决定。
        self.pub = self.create_publisher(LaserScan, "/scan", qos_profile_sensor_data)
        # 定时周期单位为秒，回调由执行器调度而非自动新建独占线程；使用节点时钟，仿真时间暂停可能影响触发。
        self.timer = self.create_timer(0.1, self.publish_scan)

    def publish_scan(self):
        msg = LaserScan()
        # 取得节点当前 ROS 时刻并转换为 sec/nanosec 消息；use_sim_time 时来自 /clock，采样时刻应尽量靠近数据生成。
        msg.header.stamp = self.get_clock().now().to_msg()
        # 坐标系名称是离散标识；它必须与数值实际表达的坐标系相符，改字符串不会完成坐标变换。
        msg.header.frame_id = "laser"
        # 扫描角度单位 rad；angle_max 必须与角度起点、增量和实际样本数相符，360个点只有359个相邻间隔。
        msg.angle_min = -math.pi
        msg.angle_increment = 2.0 * math.pi / 360.0
        msg.angle_max = msg.angle_min + 359 * msg.angle_increment
        # 有效距离上下界单位 m；真实无返回/越界样本还需遵循 LaserScan 的约定，不可随意当作零距离。
        msg.range_min = 0.05
        msg.range_max = 10.0
        # 整次扫描时长单位 s；此合成实验不模拟每束激光在该时长内的真实运动畸变。
        msg.scan_time = 0.1
        for i in range(360):
            a = msg.angle_min + i * msg.angle_increment
            # 对边长4m、中心在传感器原点的合成方房间求射线到墙距离；1e-9只避免除零，不模拟真实噪声/遮挡。
            distance = min(2.0 / max(abs(math.cos(a)), 1e-9),
                           2.0 / max(abs(math.sin(a)), 1e-9))
            # 按角度从angle_min递增的相同顺序追加米制距离；数组长度与angle_increment/angle_max约定一致。
            msg.ranges.append(distance)
        # 提交已填好的消息给 ROS 发布端；这不是业务处理完成确认，端到端接收仍取决于发现、类型、QoS 和执行器。
        self.pub.publish(msg)

# 程序入口按本章顺序组织资源；本例仅在 __main__ 下运行，import 时不应启动节点或连接硬件。
def main():
    # 初始化当前进程的 ROS 上下文并解析传入 ROS 参数；在创建节点/端点之前调用。
    rclpy.init()
    node = SquareScan()
    try:
        # 进入执行器事件循环，定时器、订阅、服务和 Future 回调在这里才被推进；通常阻塞到中断或上下文关闭。
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        # 显式释放节点所属端点与定时器；应在相关执行器不再访问节点后执行。
        node.destroy_node()
        # 检查 ROS 上下文仍有效，避免退出流程重复 shutdown；它不表示节点业务健康。
        if rclpy.ok():
            # 关闭本进程 ROS 上下文；先停止执行器、销毁端点/节点，再在上下文仍有效时调用。
            rclpy.shutdown()

if __name__ == "__main__":
    main()