#!/usr/bin/env python3
"""输入：固定的二维观测；输出：最小二乘位置、残差和投影方差。只需标准库。"""

def run():
    import math

    def solve2(matrix, vector):
        # 教学用二阶线性方程求解器；输入的两行长度均为 2。
        # 1e-12 是本例量纲统一后的绝对退化阈值，不是通用数值策略。
        a, b = matrix[0]
        c, d = matrix[1]
        determinant = a * d - b * c
        if abs(determinant) < 1e-12:
            raise ValueError('观测退化：不能唯一求解两个未知量')
        return [(d * vector[0] - b * vector[1]) / determinant,
                (-c * vector[0] + a * vector[1]) / determinant]

    # 状态为 [x, y]，单位 m；每行观测系数无量纲，b 的单位为 m。
    matrix = [[1.0, 0.0], [0.0, 1.0], [1.0, 1.0]]
    observations = [1.0, 2.0, 2.8]
    # W=I：三个观测具有相同方差。先形成 H=A^T A 和 g=A^T b。
    hessian = [[sum(row[i] * row[j] for row in matrix)
                for j in range(2)] for i in range(2)]
    gradient_rhs = [sum(row[i] * z for row, z in zip(matrix, observations))
                    for i in range(2)]
    estimate = solve2(hessian, gradient_rhs)
    residual = [sum(a * x for a, x in zip(row, estimate)) - z
                for row, z in zip(matrix, observations)]
    # 验收一：最小二乘残差应正交于 A 的两列，误差容差单位为 m。
    normal_residual = [sum(row[i] * r for row, r in zip(matrix, residual))
                       for i in range(2)]
    assert max(map(abs, normal_residual)) < 1e-12
    assert math.isclose(estimate[0], 14.0 / 15.0, abs_tol=1e-12)
    assert math.isclose(estimate[1], 29.0 / 15.0, abs_tol=1e-12)

    # 验收二：带权情形也必须满足 A^T W r=0；权重的共同缩放不改变解。
    weights = [1.0, 4.0, 1.0]
    weighted_h = [[sum(w * row[i] * row[j] for row, w in zip(matrix, weights))
                   for j in range(2)] for i in range(2)]
    weighted_g = [sum(w * row[i] * z for row, z, w in zip(matrix, observations, weights))
                  for i in range(2)]
    weighted_x = solve2(weighted_h, weighted_g)
    weighted_r = [sum(a * x for a, x in zip(row, weighted_x)) - z
                  for row, z in zip(matrix, observations)]
    assert all(abs(sum(w * row[i] * r for row, r, w in zip(matrix, weighted_r, weights))) < 1e-12
               for i in range(2))

    # 验收三：重复方向观测不会增加秩，显式拒绝奇异方程。
    try:
        solve2([[1.0, 1.0], [2.0, 2.0]], [1.0, 2.0])
    except ValueError:
        pass
    else:
        raise AssertionError('奇异矩阵本应被拒绝')

    # 协方差单位 m^2；投影 s=x+y 时必须包括相关项 2*cov(x,y)。
    covariance = [[0.04, 0.03], [0.03, 0.09]]
    variance_sum = sum(sum(row) for row in covariance)
    assert covariance[0][0] > 0.0
    assert covariance[0][0] * covariance[1][1] - covariance[0][1] ** 2 > 0.0
    assert math.isclose(variance_sum, 0.19, abs_tol=1e-12)
    # 本例 H 的特征值是 1、3，所以谱条件数为 3；A 的条件数为 sqrt(3)。
    trace = hessian[0][0] + hessian[1][1]
    gap = math.sqrt((hessian[0][0] - hessian[1][1]) ** 2 + 4 * hessian[0][1] ** 2)
    condition_h = (trace + gap) / (trace - gap)
    assert math.isclose(condition_h, 3.0, abs_tol=1e-12)
    result = {'x_m': estimate, 'residual_m': residual, 'variance_sum_m2': variance_sum,
              'condition_normal_matrix': condition_h}
    print('线性代数实验通过：', result)
    return result

if __name__ == '__main__':
    run()
