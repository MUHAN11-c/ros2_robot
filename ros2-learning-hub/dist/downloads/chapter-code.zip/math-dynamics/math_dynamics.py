#!/usr/bin/env python3
"""输入：理想单摆参数与初始状态；输出：能量守恒、耗散、力矩平衡和质量矩阵检查。"""

def run():
    import math
    mass, length, gravity = 2.0, 0.5, 9.81  # kg、m、m/s^2；杆无质量，质点在杆端。
    inertia = mass*length*length  # 转轴惯量 kg*m^2，不是质心处惯量。
    dt = 0.005  # 固定积分步长 s；本实验不含接触碰撞或执行器延迟。

    def derivative(state, viscous, torque):
        angle, rate = state
        # angle 自竖直向下方向计量(rad)，rate 单位 rad/s。
        acceleration = (torque-viscous*rate-mass*gravity*length*math.sin(angle))/inertia
        return [rate, acceleration]

    def rk4(state, viscous, torque):
        # 四阶 Runge-Kutta 是数值近似，不是严格的保能积分器。
        k1 = derivative(state, viscous, torque)
        k2 = derivative([x+dt*k/2 for x, k in zip(state, k1)], viscous, torque)
        k3 = derivative([x+dt*k/2 for x, k in zip(state, k2)], viscous, torque)
        k4 = derivative([x+dt*k for x, k in zip(state, k3)], viscous, torque)
        return [x+dt*(a+2*b+2*c+d)/6 for x, a, b, c, d in zip(state, k1, k2, k3, k4)]

    def energy(state):
        angle, rate = state
        return 0.5*inertia*rate*rate+mass*gravity*length*(1-math.cos(angle))  # J

    initial = [0.7, 0.0]
    conservative = initial.copy()
    initial_energy = energy(initial)
    for _ in range(2000):
        conservative = rk4(conservative, 0.0, 0.0)
    drift = abs(energy(conservative)-initial_energy)
    assert drift < 1e-6

    dissipative, previous_energy = initial.copy(), initial_energy
    for _ in range(2000):
        dissipative = rk4(dissipative, 0.2, 0.0)  # b 单位 N*m*s/rad。
        next_energy = energy(dissipative)
        assert next_energy <= previous_energy+1e-10
        previous_energy = next_energy
    assert energy(dissipative) < initial_energy

    # 静态平衡需要 tau=m*g*l*sin(theta)；并非所有姿态都能由限幅电机保持。
    held_angle = 0.3
    holding_torque = mass*gravity*length*math.sin(held_angle)
    assert abs(derivative([held_angle, 0.0], 0.2, holding_torque)[1]) < 1e-12
    # 能量导数 dE/dt=omega*(tau-b*omega)，用状态导数验证同一等式。
    state, b, tau = [0.3, 0.1], 0.2, 0.5
    speed, acceleration = derivative(state, b, tau)
    chain_rule = inertia*state[1]*acceleration+mass*gravity*length*math.sin(state[0])*speed
    assert math.isclose(chain_rule, state[1]*(tau-b*state[1]), abs_tol=1e-12)

    # 两个杆端质点的平面 2R 质量矩阵，验证动力学正定性与运动学奇异的区别。
    l1, l2, m1, m2 = 0.6, 0.4, 1.0, 0.5
    for q2 in (0.0, 0.4, math.pi):
        a = m1*l1*l1+m2*(l1*l1+l2*l2+2*l1*l2*math.cos(q2))
        b12 = m2*(l2*l2+l1*l2*math.cos(q2))
        d = m2*l2*l2
        assert a > 0.0 and a*d-b12*b12 > 0.0
    result = {'initial_energy_J': initial_energy, 'conservative_drift_J': drift,
              'dissipative_final_energy_J': energy(dissipative), 'holding_torque_Nm': holding_torque}
    print('动力学实验通过：', result)
    return result

if __name__ == '__main__':
    run()
