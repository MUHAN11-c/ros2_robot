# 【中文教学注释】 test_talker.py 完整文件
# 本例作用：活动测试与被测进程同时运行，关闭后的测试再核对退出状态。测试节点在 finally 中清理，避免失败后残留订阅。总期限使用单调时间，因此仿真时钟暂停不会让测试无限等待。
# 输入输出：输入为速度、纳秒时间戳和超时阈值，或受控启动的 talker；输出为断言、消息观测及测试退出状态。
# 执行顺序与边界：边界含 age==timeout、负年龄、NaN 和缺失输入；集成测试用单调时间设上限，测试节点和订阅者最后销毁，不将单元通过冒充实机安全。
import time
import unittest
import launch
import launch_ros.actions
import launch_testing
import launch_testing.actions
import launch_testing.asserts
import rclpy
from std_msgs.msg import String

def generate_test_description():
    # 这是launch的Node启动动作：package/executable定位已安装入口，name/namespace决定ROS名称，parameters与remappings在启动阶段配置；不等于rclpy运行期Node对象。
    talker = launch_ros.actions.Node(
        package='demo_nodes_cpp', executable='talker',
        namespace='integration_case', output='screen')
    # 返回 launch 动作集合，由启动系统执行；列表顺序不能作为节点发现/生命周期就绪屏障。
    return launch.LaunchDescription([
        # 通知 launch_testing 可以开始测试代码；只表示测试阶段就绪，不替代应用消息/状态的实际等待。
        talker, launch_testing.actions.ReadyToTest()
    ]), {'talker': talker}

class TestMessages(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        # 初始化当前进程的 ROS 上下文并解析传入 ROS 参数；在创建节点/端点之前调用。
        rclpy.init()

    @classmethod
    def tearDownClass(cls):
        # 关闭本进程 ROS 上下文；先停止执行器、销毁端点/节点，再在上下文仍有效时调用。
        rclpy.shutdown()

    def test_nonempty_message(self):
        # 创建并持有节点对象；本进程退出前应显式 destroy_node，创建节点本身不会自动处理回调。
        node = rclpy.create_node('integration_observer')
        received = []
        # 绑定消息类型、话题、回调和 QoS，并持有订阅对象；/开头的名称是绝对话题，回调由执行器调度。
        subscription = node.create_subscription(
            String, '/integration_case/chatter',
            lambda message: received.append(message.data), 10)
        # 读取只用于测量经过时长的单调时钟，单位 s；不会随 ROS 仿真时间暂停或回拨。
        end = time.monotonic() + 5.0
        try:
            while not received and time.monotonic() < end:
                # 最多等待 timeout_sec 秒并执行一次可用回调；返回后仍须检查消息/期限，不能当成固定周期睡眠。
                rclpy.spin_once(node, timeout_sec=0.1)
            self.assertTrue(received, 'no message within 5 seconds')
            self.assertTrue(received[0], 'message is empty')
        finally:
            # 取消订阅并释放该订阅者的 ROS 资源；测试结束后不继续占用端点。
            node.destroy_subscription(subscription)
            # 显式释放节点所属端点与定时器；应在相关执行器不再访问节点后执行。
            node.destroy_node()

@launch_testing.post_shutdown_test()
class TestExit(unittest.TestCase):
    def test_exit_code(self, proc_info, talker):
        # 在进程退出后核对被测进程退出状态；与运行期间是否收到有效消息是两项独立断言。
        launch_testing.asserts.assertExitCodes(proc_info, process=talker)