import time
import unittest
import launch
import launch_ros.actions
import launch_testing
import launch_testing.actions
import launch_testing.asserts
import rclpy
from std_msgs.msg import String

def generate_test_description():
    talker = launch_ros.actions.Node(
        package='demo_nodes_cpp', executable='talker',
        namespace='integration_case', output='screen')
    return launch.LaunchDescription([
        talker, launch_testing.actions.ReadyToTest()
    ]), {'talker': talker}

class TestMessages(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        rclpy.init()

    @classmethod
    def tearDownClass(cls):
        rclpy.shutdown()

    def test_nonempty_message(self):
        node = rclpy.create_node('integration_observer')
        received = []
        subscription = node.create_subscription(
            String, '/integration_case/chatter',
            lambda message: received.append(message.data), 10)
        end = time.monotonic() + 5.0
        try:
            while not received and time.monotonic() < end:
                rclpy.spin_once(node, timeout_sec=0.1)
            self.assertTrue(received, 'no message within 5 seconds')
            self.assertTrue(received[0], 'message is empty')
        finally:
            node.destroy_subscription(subscription)
            node.destroy_node()

@launch_testing.post_shutdown_test()
class TestExit(unittest.TestCase):
    def test_exit_code(self, proc_info, talker):
        launch_testing.asserts.assertExitCodes(proc_info, process=talker)
