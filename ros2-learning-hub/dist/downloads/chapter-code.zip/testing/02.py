import pytest
from policy import select_output

def test_fresh_command():
    assert select_output(0.4, 100, 150, 100) == 0.4

def test_timeout_boundary():
    assert select_output(0.4, 100, 200, 100) == 0.4
    assert select_output(0.4, 100, 201, 100) == 0.0

def test_missing_future_and_nonfinite():
    assert select_output(0.4, None, 150, 100) == 0.0
    assert select_output(0.4, 200, 150, 100) == 0.0
    assert select_output(float('nan'), 100, 150, 100) == 0.0

def test_invalid_timeout():
    with pytest.raises(ValueError):
        select_output(0.4, 100, 150, 0)
