import math

def select_output(speed, last_seen_ns, now_ns, timeout_ns):
    if timeout_ns <= 0:
        raise ValueError('timeout must be positive')
    if last_seen_ns is None or not math.isfinite(speed):
        return 0.0
    age = now_ns - last_seen_ns
    if age < 0 or age > timeout_ns:
        return 0.0
    return speed
