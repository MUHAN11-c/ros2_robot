def step(position, requested_velocity, dt, velocity_limit):
    if dt <= 0 or velocity_limit <= 0:
        raise ValueError("positive dt and limit required")
    velocity = max(-velocity_limit, min(velocity_limit, requested_velocity))
    return position + velocity * dt

if __name__ == "__main__":
    q = 0.0
    for _ in range(100):
        q = step(q, 0.2, 0.01, 0.1)
    assert abs(q - 0.1) < 1e-9
    print("position after one second:", q)
