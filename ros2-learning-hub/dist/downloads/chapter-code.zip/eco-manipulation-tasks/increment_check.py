# 【中文教学注释】 increment_check.py：完整离线实验
# 本例作用：输出应为约零点一弧度，因为请求速度被限幅。本次编写未执行该实验。
# 输入输出：输入为任务状态或 requested_velocity；输出为受限位置增量和任务成功/失败分支。
# 执行顺序与边界：离线积分中位置 rad、速度 rad/s、dt s；先限速再积分，只验证数值接口，不具备完整碰撞、抓持力或失效安全保证。
def step(position, requested_velocity, dt, velocity_limit):
    if dt <= 0 or velocity_limit <= 0:
        raise ValueError("positive dt and limit required")
    # 把请求角速度限于±velocity_limit(rad/s)，再用于位置积分；只做运动学限幅，没有力矩、加速度或碰撞约束。
    velocity = max(-velocity_limit, min(velocity_limit, requested_velocity))
    # 前向离散积分q_next=q+v×dt，q单位rad、dt单位s；本示例要求正周期与正速率上限。
    return position + velocity * dt

if __name__ == "__main__":
    q = 0.0
    for _ in range(100):
        q = step(q, 0.2, 0.01, 0.1)
    # 断言检验本例明确的数值/边界性质；失败立即暴露问题，不能用这里的合成样本证明所有输入或实机安全。
    assert abs(q - 0.1) < 1e-9
    print("position after one second:", q)