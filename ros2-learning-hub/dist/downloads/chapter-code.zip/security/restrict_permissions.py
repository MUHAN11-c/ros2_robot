# 【中文教学注释】 restrict_permissions.py 完整实验脚本
# 本例作用：脚本先移除原允许规则，避免旧的广泛权限继续生效，再写唯一域和允许清单，最后用权限 CA 签名。check=True 使签名失败立即报错；不应在失败后继续把旧权限当作新策略。它使用的是权限 CA 私钥，不是某个节点的身份私钥。
# 输入输出：输入为实验密钥库、enclave 与 DDS 权限规则；输出为签名权限文件和受限通信结果。
# 执行顺序与边界：先创建身份和签名材料，再显式选 DDS 后端并启用 Enforce；示例仅用于独立实验目录，修改 XML 后必须重签，私钥不能随学习包发布。
from pathlib import Path
import subprocess
import xml.etree.ElementTree as ET

root = Path('keystore').resolve()
for role in ('talker', 'listener'):
    enclave = root / 'enclaves' / 'lab' / role
    path = enclave / 'permissions.xml'
    # 读取实验权限 XML；后续只修改本实验授权规则，修改后旧签名失效，必须重新签名。
    tree = ET.parse(path)
    grant = tree.getroot().find('./permissions/grant')
    if grant is None:
        raise RuntimeError(f'grant missing: {path}')
    for child in list(grant):
        if child.tag in ('allow_rule', 'deny_rule', 'default'):
            grant.remove(child)
    rule = ET.SubElement(grant, 'allow_rule')
    domains = ET.SubElement(rule, 'domains')
    ET.SubElement(domains, 'id').text = '42'
    # 为本实验角色生成服务内部通道匹配范围；通配规则需按目标RMW实际名称展开核对，不能无条件沿用到其他机器人。
    own_services = f'*/{role}/*'
    published = ['rt/rosout', 'rt/parameter_events',
                 own_services, 'ros_discovery_info']
    subscribed = ['rt/parameter_events', own_services, 'ros_discovery_info']
    if role == 'talker':
        published.append('rt/chatter')
    else:
        subscribed.append('rt/chatter')
    for direction, names in (('publish', published), ('subscribe', subscribed)):
        topics = ET.SubElement(ET.SubElement(rule, direction), 'topics')
        for name in names:
            ET.SubElement(topics, 'topic').text = name
    # 未由allow_rule明确授权的行为默认拒绝；签名后的权限文件才会被DDS安全插件采信。
    ET.SubElement(grant, 'default').text = 'DENY'
    ET.indent(tree, space='  ')
    tree.write(path, encoding='utf-8', xml_declaration=True)
    # 以参数列表调用 openssl 重签权限文件，check=True 使失败显式抛出；不使用 shell 拼接，不输出私钥内容。
    subprocess.run([
        'openssl', 'smime', '-sign', '-text',
        '-in', str(path), '-out', str(enclave / 'permissions.p7s'),
        '-signer', str(enclave / 'permissions_ca.cert.pem'),
        '-inkey', str(root / 'private' / 'permissions_ca.key.pem')
    ], check=True)
    print(f'updated and signed: {role}')