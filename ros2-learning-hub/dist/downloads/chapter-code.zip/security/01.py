from pathlib import Path
import subprocess
import xml.etree.ElementTree as ET

root = Path('keystore').resolve()
for role in ('talker', 'listener'):
    enclave = root / 'enclaves' / 'lab' / role
    path = enclave / 'permissions.xml'
    tree = ET.parse(path)
    grant = tree.getroot().find('./permissions/grant')
    if grant is None:
        raise RuntimeError(f'grant missing: {path}')
    for child in list(grant):
        if child.tag in ('allow_rule', 'deny_rule', 'default'):
            grant.remove(child)
    rule = ET.SubElement(grant, 'allow_rule')
    domains = ET.SubElement(rule, 'domains')
    ET.SubElement(domains, 'id').text = '42'
    own_services = f'*/{role}/*'
    published = ['rt/rosout', 'rt/parameter_events',
                 own_services, 'ros_discovery_info']
    subscribed = ['rt/parameter_events', own_services, 'ros_discovery_info']
    if role == 'talker':
        published.append('rt/chatter')
    else:
        subscribed.append('rt/chatter')
    for direction, names in (('publish', published), ('subscribe', subscribed)):
        topics = ET.SubElement(ET.SubElement(rule, direction), 'topics')
        for name in names:
            ET.SubElement(topics, 'topic').text = name
    ET.SubElement(grant, 'default').text = 'DENY'
    ET.indent(tree, space='  ')
    tree.write(path, encoding='utf-8', xml_declaration=True)
    subprocess.run([
        'openssl', 'smime', '-sign', '-text',
        '-in', str(path), '-out', str(enclave / 'permissions.p7s'),
        '-signer', str(enclave / 'permissions_ca.cert.pem'),
        '-inkey', str(root / 'private' / 'permissions_ca.key.pem')
    ], check=True)
    print(f'updated and signed: {role}')
