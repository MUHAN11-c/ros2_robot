import rclpy
from rclpy.node import Node
from rclpy.clock import Clock, ClockType

def main():
    rclpy.init()
    node = Node('clock_probe')
    steady = Clock(clock_type=ClockType.STEADY_TIME)
    timer = node.create_timer(
        1.0, lambda: node.get_logger().info(
            f'ros_time_ns={node.get_clock().now().nanoseconds}'),
        clock=steady)
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_timer(timer)
        node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()

if __name__ == '__main__':
    main()
