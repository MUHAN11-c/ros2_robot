# 【中文教学注释】 clock_probe.py 完整脚本
# 本例作用：单调时钟只负责一秒一次的观察节奏；node.get_clock 返回节点选定的 ROS 时钟。两种时钟用于不同目的，不在同一个时间差公式中相减。
# 输入输出：输入为话题数据、Header 时间戳与选定时钟；输出为 bag 文件、回放消息和时间观测值。
# 执行顺序与边界：先录制再停止检查，回放前停掉同话题实时发布者；use_sim_time 需 /clock，暂停/跳转可能使 ROS 时间停住或倒退，QoS 覆盖不修复原始坏数据。
import rclpy
from rclpy.node import Node
from rclpy.clock import Clock, ClockType

# 程序入口按本章顺序组织资源；本例仅在 __main__ 下运行，import 时不应启动节点或连接硬件。
def main():
    # 初始化当前进程的 ROS 上下文并解析传入 ROS 参数；在创建节点/端点之前调用。
    rclpy.init()
    # 创建并持有节点对象；本进程退出前应显式 destroy_node，创建节点本身不会自动处理回调。
    node = Node('clock_probe')
    steady = Clock(clock_type=ClockType.STEADY_TIME)
    # 定时周期单位为秒，回调由执行器调度而非自动新建独占线程；显式clock=steady驱动观察节奏；/clock暂停不暂停此timer，回调读取的节点ROS时间仍可能停止。
    timer = node.create_timer(
        # 输出可观测日志用于核对状态；日志成功写出不等于对端收到消息或任务执行成功。
        1.0, lambda: node.get_logger().info(
            # 时间字段中的 sec 为秒、nanosec 为纳秒，1秒=10^9纳秒；二者不是相互独立的任意整数。
            f'ros_time_ns={node.get_clock().now().nanoseconds}'),
        clock=steady)
    try:
        # 进入执行器事件循环，定时器、订阅、服务和 Future 回调在这里才被推进；通常阻塞到中断或上下文关闭。
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_timer(timer)
        # 显式释放节点所属端点与定时器；应在相关执行器不再访问节点后执行。
        node.destroy_node()
        # 检查 ROS 上下文仍有效，避免退出流程重复 shutdown；它不表示节点业务健康。
        if rclpy.ok():
            # 关闭本进程 ROS 上下文；先停止执行器、销毁端点/节点，再在上下文仍有效时调用。
            rclpy.shutdown()

if __name__ == '__main__':
    main()