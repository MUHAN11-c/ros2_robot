#!/usr/bin/env python3
"""输入：两连杆长度(m)、角度(rad)、角速度(rad/s)；输出：位置、雅可比和力矩。"""

def run():
    import math
    length_1, length_2 = 0.6, 0.4  # 两个刚性杆的长度，单位 m。

    def forward(q):
        a, b = q
        return [length_1*math.cos(a)+length_2*math.cos(a+b),
                length_1*math.sin(a)+length_2*math.sin(a+b)]

    def jacobian(q):
        a, b = q
        return [[-length_1*math.sin(a)-length_2*math.sin(a+b), -length_2*math.sin(a+b)],
                [length_1*math.cos(a)+length_2*math.cos(a+b), length_2*math.cos(a+b)]]

    def inverse(point, elbow_sign):
        # elbow_sign 为 +1 或 -1，显式选择肘部两种支路；越界目标必须拒绝。
        px, py = point
        cosine = (px*px+py*py-length_1**2-length_2**2)/(2*length_1*length_2)
        if cosine < -1.0-1e-12 or cosine > 1.0+1e-12:
            raise ValueError('目标不在两连杆可达环带内')
        # 仅钳位浮点舍入误差，不能把真实越界目标投射成可达目标。
        q2 = elbow_sign*math.acos(min(1.0, max(-1.0, cosine)))
        q1 = math.atan2(py, px)-math.atan2(length_2*math.sin(q2), length_1+length_2*math.cos(q2))
        return [q1, q2]

    q = [math.pi/6.0, -math.pi/3.0]
    position = forward(q)
    j = jacobian(q)
    step = 1e-6  # 雅可比差分的角度扰动，单位 rad。
    for joint in range(2):
        plus, minus = q.copy(), q.copy()
        plus[joint] += step
        minus[joint] -= step
        numerical = [(a-b)/(2*step) for a, b in zip(forward(plus), forward(minus))]
        assert max(abs(numerical[i]-j[i][joint]) for i in range(2)) < 1e-8
    recovered = inverse(position, -1)
    assert max(abs(a-b) for a, b in zip(recovered, q)) < 1e-12
    for branch in (-1, 1):
        p = forward(inverse(position, branch))
        assert max(abs(a-b) for a, b in zip(p, position)) < 1e-12
    try:
        inverse([2.0, 0.0], 1)
    except ValueError:
        pass
    else:
        raise AssertionError('不可达点本应被拒绝')

    # J 的单位 m/rad；qdot 单位 rad/s，因此末端速度单位 m/s。
    rates = [0.2, -0.1]
    velocity = [sum(a*b for a, b in zip(row, rates)) for row in j]
    force = [2.0, 3.0]  # 在同一个基坐标系表达的末端力，单位 N。
    torque = [sum(j[i][k]*force[i] for i in range(2)) for k in range(2)]
    # 虚功/功率一致性：tau^T*qdot 与 F^T*pdot 均为 W。
    power_joint = sum(a*b for a, b in zip(torque, rates))
    power_tip = sum(a*b for a, b in zip(force, velocity))
    assert math.isclose(power_joint, power_tip, abs_tol=1e-12)
    determinant = j[0][0]*j[1][1]-j[0][1]*j[1][0]
    assert math.isclose(determinant, length_1*length_2*math.sin(q[1]), abs_tol=1e-12)
    straight = jacobian([0.3, 0.0])
    assert abs(straight[0][0]*straight[1][1]-straight[0][1]*straight[1][0]) < 1e-12
    result = {'tip_position_m': position, 'tip_velocity_m_s': velocity,
              'joint_torque_Nm': torque, 'power_W': power_tip}
    print('运动学实验通过：', result)
    return result

if __name__ == '__main__':
    run()
