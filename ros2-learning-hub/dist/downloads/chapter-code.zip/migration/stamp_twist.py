# 【中文教学注释】 stamp_twist.py 完整教学适配器
# 本例作用：发布与订阅采用明确的不同主题，避免形成回路。赋给 twist 的是原消息数值；新 Header 来自适配器当前时钟。仿真使用时适配器与消费者必须一致设置 use_sim_time。
# 输入输出：输入为旧 Twist 或待迁移接口/参数；输出为新消息结构和兼容性检查结果。
# 执行顺序与边界：速度值仍是 m/s、rad/s；适配器用接收时刻补 stamp，并不能恢复旧消息真实采样时间或完成坐标变换，两个输出发布者会产生竞争。
import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist, TwistStamped

class StampTwist(Node):
    def __init__(self):
        # 构造 Node 基类并确定节点名；后续相对话题/服务名由命名空间解析，重命名需与参数文件选择器对应。
        super().__init__('stamp_twist')
        # 创建指定消息类型和话题的发布端并持久保存；整数 QoS 是 KeepLast 历史深度，不是 Hz，真正发送由 publish 调用决定。
        self.publisher = self.create_publisher(
            TwistStamped, '/migration/stamped_cmd', 10)
        # 绑定消息类型、话题、回调和 QoS，并持有订阅对象；/开头的名称是绝对话题，回调由执行器调度。
        self.subscription = self.create_subscription(
            Twist, '/migration/legacy_cmd', self.receive, 10)

    def receive(self, message):
        output = TwistStamped()
        # 取得节点当前 ROS 时刻并转换为 sec/nanosec 消息；use_sim_time 时来自 /clock，采样时刻应尽量靠近数据生成。
        output.header.stamp = self.get_clock().now().to_msg()
        # 坐标系名称是离散标识；它必须与数值实际表达的坐标系相符，改字符串不会完成坐标变换。
        output.header.frame_id = 'base_link'
        output.twist = message
        # 提交已填好的消息给 ROS 发布端；这不是业务处理完成确认，端到端接收仍取决于发现、类型、QoS 和执行器。
        self.publisher.publish(output)

# 程序入口按本章顺序组织资源；本例仅在 __main__ 下运行，import 时不应启动节点或连接硬件。
def main():
    # 初始化当前进程的 ROS 上下文并解析传入 ROS 参数；在创建节点/端点之前调用。
    rclpy.init()
    node = StampTwist()
    try:
        # 进入执行器事件循环，定时器、订阅、服务和 Future 回调在这里才被推进；通常阻塞到中断或上下文关闭。
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        # 显式释放节点所属端点与定时器；应在相关执行器不再访问节点后执行。
        node.destroy_node()
        # 检查 ROS 上下文仍有效，避免退出流程重复 shutdown；它不表示节点业务健康。
        if rclpy.ok():
            # 关闭本进程 ROS 上下文；先停止执行器、销毁端点/节点，再在上下文仍有效时调用。
            rclpy.shutdown()

if __name__ == '__main__':
    main()