import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist, TwistStamped

class StampTwist(Node):
    def __init__(self):
        super().__init__('stamp_twist')
        self.publisher = self.create_publisher(
            TwistStamped, '/migration/stamped_cmd', 10)
        self.subscription = self.create_subscription(
            Twist, '/migration/legacy_cmd', self.receive, 10)

    def receive(self, message):
        output = TwistStamped()
        output.header.stamp = self.get_clock().now().to_msg()
        output.header.frame_id = 'base_link'
        output.twist = message
        self.publisher.publish(output)

def main():
    rclpy.init()
    node = StampTwist()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()

if __name__ == '__main__':
    main()
