owners = {}

def acquire(resource, robot):
    current = owners.get(resource)
    if current is None or current == robot:
        owners[resource] = robot
        return True
    return False

def release(resource, robot):
    if owners.get(resource) != robot:
        raise ValueError("only owner may release")
    del owners[resource]

assert acquire("door_a", "robot1")
assert not acquire("door_a", "robot2")
release("door_a", "robot1")
assert acquire("door_a", "robot2")
print("reservation model checks passed")
