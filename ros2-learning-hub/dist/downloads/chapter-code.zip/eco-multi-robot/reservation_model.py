# 【中文教学注释】 reservation_model.py
# 本例作用：纯 Python 概念实验，未在本次执行；不能作为真实交通安全控制器。
# 输入输出：输入为命名空间/域配置或资源占用请求；输出为隔离后的图和占用许可。
# 执行顺序与边界：资源名/机器人名为离散标识；示例字典只有单进程顺序语义，没有分布式原子性、租约或故障恢复，命名空间也不是网络隔离或权限控制。
owners = {}

# 单进程内检查离散资源归属；同一所有者重复请求可成功，不同机器人不能同时持有同一资源。
def acquire(resource, robot):
    current = owners.get(resource)
    if current is None or current == robot:
        owners[resource] = robot
        return True
    return False

# 只允许当前所有者释放资源；此字典没有分布式锁、租约或进程崩溃恢复功能。
def release(resource, robot):
    if owners.get(resource) != robot:
        raise ValueError("only owner may release")
    del owners[resource]

# 断言检验本例明确的数值/边界性质；失败立即暴露问题，不能用这里的合成样本证明所有输入或实机安全。
assert acquire("door_a", "robot1")
assert not acquire("door_a", "robot2")
release("door_a", "robot1")
assert acquire("door_a", "robot2")
print("reservation model checks passed")