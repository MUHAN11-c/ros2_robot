# 【中文教学注释】 wheel_measurement.py
# 本例作用：这是独立的合成测量节点，只供验证滤波输入合同。
# 输入输出：输入为轮速 Odometry 和协方差、滤波配置；输出为融合里程计及选定 TF。
# 执行顺序与边界：线速度 m/s，姿态/角速度分别 rad、rad/s；15维配置向量顺序固定。示例只融合 x 速度，TF 只保留一个发布者，协方差不是任意置信百分比。
import rclpy
from rclpy.node import Node
from nav_msgs.msg import Odometry

class WheelMeasurement(Node):
    def __init__(self):
        # 构造 Node 基类并确定节点名；后续相对话题/服务名由命名空间解析，重命名需与参数文件选择器对应。
        super().__init__("wheel_measurement")
        # 创建指定消息类型和话题的发布端并持久保存；整数 QoS 是 KeepLast 历史深度，不是 Hz，真正发送由 publish 调用决定。
        self.pub = self.create_publisher(Odometry, "/wheel/odom", 10)
        # 定时周期单位为秒，回调由执行器调度而非自动新建独占线程；使用节点时钟，仿真时间暂停可能影响触发。
        self.timer = self.create_timer(0.1, self.publish_measurement)

    def publish_measurement(self):
        m = Odometry()
        # 取得节点当前 ROS 时刻并转换为 sec/nanosec 消息；use_sim_time 时来自 /clock，采样时刻应尽量靠近数据生成。
        m.header.stamp = self.get_clock().now().to_msg()
        # 坐标系名称是离散标识；它必须与数值实际表达的坐标系相符，改字符串不会完成坐标变换。
        m.header.frame_id = "odom"
        # 标明子坐标系；Odometry 中 pose 与 twist 的参考语义不同，不因字段填名就自动广播 TF。
        m.child_frame_id = "base_link"
        # 平面 yaw 用 z=sin(yaw/2)、w=cos(yaw/2) 构造单位四元数；yaw 单位 rad，x/y分量保持0。
        m.pose.pose.orientation.w = 1.0
        # Odometry 的前向速度单位 m/s；本例是合成测量，未同时积分位置或读取硬件编码器。
        m.twist.twist.linear.x = 0.1
        for i in [0, 7, 14, 21, 28, 35]:
            # 6×6协方差按行展平，对角下标0/7/14/21/28/35；不同分量单位分别是速度/角速度单位的平方。
            m.twist.covariance[i] = 0.01
        # 提交已填好的消息给 ROS 发布端；这不是业务处理完成确认，端到端接收仍取决于发现、类型、QoS 和执行器。
        self.pub.publish(m)

# 程序入口按本章顺序组织资源；本例仅在 __main__ 下运行，import 时不应启动节点或连接硬件。
def main():
    # 初始化当前进程的 ROS 上下文并解析传入 ROS 参数；在创建节点/端点之前调用。
    rclpy.init()
    n = WheelMeasurement()
    try:
        # 进入执行器事件循环，定时器、订阅、服务和 Future 回调在这里才被推进；通常阻塞到中断或上下文关闭。
        rclpy.spin(n)
    except KeyboardInterrupt:
        pass
    finally:
        # 显式释放节点所属端点与定时器；应在相关执行器不再访问节点后执行。
        n.destroy_node()
        # 检查 ROS 上下文仍有效，避免退出流程重复 shutdown；它不表示节点业务健康。
        if rclpy.ok():
            # 关闭本进程 ROS 上下文；先停止执行器、销毁端点/节点，再在上下文仍有效时调用。
            rclpy.shutdown()

if __name__ == "__main__":
    main()