import rclpy
from rclpy.node import Node
from nav_msgs.msg import Odometry

class WheelMeasurement(Node):
    def __init__(self):
        super().__init__("wheel_measurement")
        self.pub = self.create_publisher(Odometry, "/wheel/odom", 10)
        self.timer = self.create_timer(0.1, self.publish_measurement)

    def publish_measurement(self):
        m = Odometry()
        m.header.stamp = self.get_clock().now().to_msg()
        m.header.frame_id = "odom"
        m.child_frame_id = "base_link"
        m.pose.pose.orientation.w = 1.0
        m.twist.twist.linear.x = 0.1
        for i in [0, 7, 14, 21, 28, 35]:
            m.twist.covariance[i] = 0.01
        self.pub.publish(m)

def main():
    rclpy.init()
    n = WheelMeasurement()
    try:
        rclpy.spin(n)
    except KeyboardInterrupt:
        pass
    finally:
        n.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()

if __name__ == "__main__":
    main()
