def manipulation_lab():
    """验证单关节静止到静止五次轨迹的端点与全程速度、加速度上界。"""
    import math

    # 输入：关节角差 rad，速度限制 rad/s，加速度限制 rad/s²。
    q0,q1,v_limit,a_limit = 0.0,1.2,0.6,1.0
    delta = q1-q0
    # s(tau)=10tau³-15tau⁴+6tau⁵；其导数极值可解析求得。
    # 常数 1.875 与 10/sqrt(3) 是该特定五次曲线的极值，不适用于任意轨迹。
    duration_s = max(1.875*abs(delta)/v_limit,
                     math.sqrt((10/math.sqrt(3))*abs(delta)/a_limit))

    def sample(t_s):
        tau = t_s/duration_s
        assert 0.0 <= tau <= 1.0
        s = 10*tau**3-15*tau**4+6*tau**5
        sd = 30*tau**2-60*tau**3+30*tau**4
        sdd = 60*tau-180*tau**2+120*tau**3
        return q0+delta*s,delta*sd/duration_s,delta*sdd/duration_s**2

    assert sample(0.0) == (q0,0.0,0.0)
    end = sample(duration_s)
    assert math.isclose(end[0],q1) and abs(end[1])+abs(end[2]) < 1e-12
    values = [sample(duration_s*i/1000) for i in range(1001)]
    assert max(abs(v[1]) for v in values) <= v_limit+1e-12
    assert max(abs(v[2]) for v in values) <= a_limit+1e-12
    # 端点速度/加速度为零并不表示 jerk 也为零，更不证明多关节路径无碰撞。
    result = {"轨迹时间_s": duration_s, "最大采样速度_rad_s": max(abs(v[1]) for v in values),
              "最大采样加速度_rad_s2": max(abs(v[2]) for v in values)}
    print("机械臂时间参数化", result)
    return result

if __name__ == "__main__":
    manipulation_lab()
