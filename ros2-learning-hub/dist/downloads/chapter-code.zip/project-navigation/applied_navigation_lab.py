def navigation_lab():
    """计算延迟加恒减速停车距离，并检查导航任务结果的幂等处理。"""
    import math

    # 输入：车速 m/s，感知到制动的延迟 s，有效减速度正值 m/s²。
    speed_m_s,latency_s,deceleration_m_s2 = 0.6,0.2,0.8
    assert speed_m_s >= 0 and latency_s >= 0 and deceleration_m_s2 > 0
    reaction_m = speed_m_s*latency_s
    brake_m = speed_m_s**2/(2*deceleration_m_s2)
    stop_m = reaction_m+brake_m
    assert math.isclose(stop_m,0.345)
    assert stop_m < 2*speed_m_s*latency_s+(2*speed_m_s)**2/(2*deceleration_m_s2)
    # 输入事件可能重复；只接受当前任务的首个终态，旧任务回调不能覆盖新任务。
    active_goal, terminal = "goal-B", None
    events = [("goal-A","SUCCEEDED"),("goal-B","CANCELED"),("goal-B","SUCCEEDED")]
    for goal_id,status in events:
        if goal_id == active_goal and terminal is None:
            terminal = status
    assert terminal == "CANCELED"
    result = {"反应距离_m": reaction_m, "制动距离_m": brake_m,
              "理想停车总距离_m": stop_m, "当前任务唯一终态": terminal}
    print("导航任务合同", result)
    return result

if __name__ == "__main__":
    navigation_lab()
