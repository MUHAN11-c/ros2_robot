import argparse
import math
import time
import rclpy
from rclpy.parameter import Parameter
from geometry_msgs.msg import PoseStamped
from nav2_simple_commander.robot_navigator import BasicNavigator, TaskResult

def pose(nav, values):
    x, y, yaw = values
    result = PoseStamped()
    result.header.frame_id = "map"
    result.header.stamp = nav.get_clock().now().to_msg()
    result.pose.position.x = x
    result.pose.position.y = y
    result.pose.orientation.z = math.sin(yaw / 2.0)
    result.pose.orientation.w = math.cos(yaw / 2.0)
    return result

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--start", nargs=3, type=float, required=True)
    parser.add_argument("--goal", nargs=3, type=float, required=True)
    parser.add_argument("--timeout", type=float, default=60.0)
    parser.add_argument("--sim-time", action="store_true")
    args = parser.parse_args()
    if args.timeout <= 0:
        parser.error("timeout must be positive")
    rclpy.init(args=[])
    nav = BasicNavigator()
    nav.set_parameters([Parameter("use_sim_time", Parameter.Type.BOOL, args.sim_time)])
    try:
        nav.setInitialPose(pose(nav, args.start))
        nav.waitUntilNav2Active()
        if not nav.goToPose(pose(nav, args.goal)):
            print("rejected")
            return
        deadline = time.monotonic() + args.timeout
        cancellation_requested = False
        while not nav.isTaskComplete():
            if time.monotonic() >= deadline and not cancellation_requested:
                nav.cancelTask()
                cancellation_requested = True
            time.sleep(0.1)
        result = nav.getResult()
        names = {TaskResult.SUCCEEDED: "succeeded",
                 TaskResult.CANCELED: "canceled",
                 TaskResult.FAILED: "failed"}
        print(names.get(result, "unknown"))
    finally:
        nav.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()

if __name__ == "__main__":
    main()
