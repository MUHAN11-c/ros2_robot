import csv
import math
import sys

with open(sys.argv[1], newline='', encoding='utf-8') as stream:
    rows = list(csv.DictReader(stream))
if not rows:
    raise SystemExit('no samples')
sequences = []
waiting_ms = []
callback_ms = []
for row in rows:
    sequence = int(row['seq'])
    sent, start, end = (int(row[key]) for key in ('send_ns', 'start_ns', 'end_ns'))
    if not sent <= start <= end:
        raise ValueError(f'invalid clock ordering at sequence {sequence}')
    sequences.append(sequence)
    waiting_ms.append((start - sent) / 1_000_000)
    callback_ms.append((end - start) / 1_000_000)

def report(name, values):
    ordered = sorted(values)
    def percentile(fraction):
        index = max(0, math.ceil(fraction * len(ordered)) - 1)
        return ordered[index]
    print(name, {
        'count': len(ordered),
        'mean_ms': sum(ordered) / len(ordered),
        'p50_ms': percentile(0.50),
        'p95_ms': percentile(0.95),
        'p99_ms': percentile(0.99),
        'max_ms': ordered[-1],
    })

report('publish_to_callback_start', waiting_ms)
report('callback_duration', callback_ms)
unique = set(sequences)
print('duplicate_samples', len(sequences) - len(unique))
print('missing_inside_observed_range', max(unique) - min(unique) + 1 - len(unique))
print('out_of_order_pairs', sum(b < a for a, b in zip(sequences, sequences[1:])))
