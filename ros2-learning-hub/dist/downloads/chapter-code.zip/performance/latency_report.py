# 【中文教学注释】 latency_report.py 完整分析脚本
# 本例作用：用 python3 latency_report.py sample_latency.csv 运行。程序拒绝时钟顺序矛盾的样本，而不是把负延迟取绝对值；跨机器未经同步的数据不能靠此脚本自动修复。分析以单一发布者且序号不重置为前提。
# 输入输出：输入为合成 CSV 或真实追踪事件；输出为等待/回调时延、分位数和样本缺失等统计。
# 执行顺序与边界：CSV 时间均为 ns，除以 1,000,000 才是 ms；端到端时延不能与回调执行时间混淆，合成数据和一次追踪都不能证明实时性上界。
import csv
import math
import sys

with open(sys.argv[1], newline='', encoding='utf-8') as stream:
    rows = list(csv.DictReader(stream))
if not rows:
    raise SystemExit('no samples')
sequences = []
waiting_ms = []
callback_ms = []
for row in rows:
    sequence = int(row['seq'])
    sent, start, end = (int(row[key]) for key in ('send_ns', 'start_ns', 'end_ns'))
    if not sent <= start <= end:
        raise ValueError(f'invalid clock ordering at sequence {sequence}')
    sequences.append(sequence)
    # 把纳秒差转换为毫秒：1 ms = 1,000,000 ns；先确保两个时间戳来自可比较的时钟。
    waiting_ms.append((start - sent) / 1_000_000)
    callback_ms.append((end - start) / 1_000_000)

def report(name, values):
    ordered = sorted(values)
    # 非空样本的nearest-rank分位数：索引ceil(q×N)-1；与GPU教学数组中的线性插值定义不同。
    def percentile(fraction):
        # nearest-rank分位数使用ceil(q×N)-1并夹住下界；这是经验样本统计定义，有限样本p99不是时延上界。
        index = max(0, math.ceil(fraction * len(ordered)) - 1)
        return ordered[index]
    print(name, {
        'count': len(ordered),
        'mean_ms': sum(ordered) / len(ordered),
        'p50_ms': percentile(0.50),
        'p95_ms': percentile(0.95),
        'p99_ms': percentile(0.99),
        'max_ms': ordered[-1],
    })

report('publish_to_callback_start', waiting_ms)
report('callback_duration', callback_ms)
# 按序号集合区分重复和观测范围内缺号；没有观测范围外的期望总数，不能推算完整丢包率。
unique = set(sequences)
print('duplicate_samples', len(sequences) - len(unique))
print('missing_inside_observed_range', max(unique) - min(unique) + 1 - len(unique))
print('out_of_order_pairs', sum(b < a for a, b in zip(sequences, sequences[1:])))