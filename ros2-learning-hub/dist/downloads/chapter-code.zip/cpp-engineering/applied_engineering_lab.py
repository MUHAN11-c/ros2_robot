def engineering_lab():
    """检查延迟预算与测量新鲜度；这是模型验算，不是实际实时性测试。"""
    from math import ceil, isclose

    # 输入：所有时间以秒表示；周期 0.02 s 对应名义 50 Hz。
    deadline_s = 0.020
    stages_s = {"感知": 0.004, "排队": 0.007, "求解": 0.003, "发布": 0.002}
    total_s = sum(stages_s.values())
    assert isclose(total_s, 0.016)
    assert total_s < deadline_s
    # 边界：排队额外增加 0.009 s 后越过截止期，不能靠平均频率掩盖。
    assert total_s + 0.009 > deadline_s

    # 输入：同一时钟下的当前时刻、采样时刻与允许测量年龄，单位均为秒。
    now_s, max_age_s = 0.120, 0.030
    timestamps_s = [0.000, 0.020, 0.040, 0.100, 0.130]
    accepted = [t for t in timestamps_s if 0.0 <= now_s - t <= max_age_s]
    assert accepted == [0.100]  # 过旧数据和未来时间戳都拒绝。
    # 容量下界只针对“生产者暂停消费 0.06 s”的确定性模型，不保证调度实时性。
    capacity = ceil(50.0 * 0.060) + 1
    assert capacity == 4
    result = {"预算总延迟_ms": total_s * 1000, "余量_ms": (deadline_s-total_s)*1000,
              "接收时间戳_s": accepted, "建议最小缓存槽": capacity}
    print("工程预算", result)
    return result

if __name__ == "__main__":
    engineering_lab()
