#include <chrono>
#include <memory>
#include "rclcpp/rclcpp.hpp"
#include "rclcpp_components/register_node_macro.hpp"
#include "std_msgs/msg/string.hpp"

namespace hub {
class Talker : public rclcpp::Node {
public:
  explicit Talker(const rclcpp::NodeOptions & options)
  : Node("hub_talker", options) {
    publisher_ = create_publisher<std_msgs::msg::String>("chatter", 10);
    timer_ = create_wall_timer(std::chrono::seconds(1), [this]() {
      auto message = std::make_unique<std_msgs::msg::String>();
      message->data = "component ready";
      publisher_->publish(std::move(message));
    });
  }
private:
  rclcpp::Publisher<std_msgs::msg::String>::SharedPtr publisher_;
  rclcpp::TimerBase::SharedPtr timer_;
};
}
RCLCPP_COMPONENTS_REGISTER_NODE(hub::Talker)
