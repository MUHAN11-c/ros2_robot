// 【中文教学注释】 src/hub_component/src/talker.cpp
// 本例作用：构造函数只建立通信实体并返回；成员引用保持发布者与定时器存活。unique_ptr 表达消息所有权转移，为支持的进程内路径提供优化条件；宏注册的全限定类名必须与 CMake 和加载命令一致。
// 输入输出：输入为已安装组件插件、容器和 NodeOptions；输出为已装入同一进程的节点与话题。
// 执行顺序与边界：C++ 组件由容器持有，无独立 main；注册插件、导出库、安装、加载缺一不可。进程内通信要求相应选项，组件故障仍可影响同一容器。
#include <chrono>
#include <memory>
#include "rclcpp/rclcpp.hpp"
#include "rclcpp_components/register_node_macro.hpp"
#include "std_msgs/msg/string.hpp"

namespace hub {
class Talker : public rclcpp::Node {
public:
  // 组件从容器接收NodeOptions，包括参数覆盖和进程内通信配置；不能将其当作已经启动的节点。
  explicit Talker(const rclcpp::NodeOptions & options)
  : Node("hub_talker", options) {
    // 创建指定模板消息类型和话题的发布端；整数10是KeepLast历史条数，不是频率。发布者必须作为成员或其他长寿命对象保留。
    publisher_ = create_publisher<std_msgs::msg::String>("chatter", 10);
    // 创建墙钟/稳态周期定时器，chrono时长明确单位；回调由执行器调度，不随/clock仿真时钟暂停而自然暂停。
    timer_ = create_wall_timer(std::chrono::seconds(1), [this]() {
      auto message = std::make_unique<std_msgs::msg::String>();
      message->data = "component ready";
      // 提交当前消息给发布端；日志/返回不提供订阅者业务处理确认，端到端行为还取决于QoS、网络和对端执行器。
      publisher_->publish(std::move(message));
    });
  }
private:
  // 持久共享句柄维持ROS对象/目标的寿命；智能指针只管理生存期，不自动解决多线程数据竞争。
  rclcpp::Publisher<std_msgs::msg::String>::SharedPtr publisher_;
  rclcpp::TimerBase::SharedPtr timer_;
};
}
// 导出可被class_loader发现的组件工厂；还需CMake注册/安装，组件NodeOptions构造与容器共同管理生命周期。
RCLCPP_COMPONENTS_REGISTER_NODE(hub::Talker)