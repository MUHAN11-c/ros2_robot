# 【中文教学注释】 pair.launch.py 完整文件
# 本例作用：两个描述创建两个节点实例但共享容器进程；相同的选项分别传给双方。此文件展示部署配置，不应与上一实验中尚在运行的同名话题发布者混用。
# 输入输出：输入为已安装组件插件、容器和 NodeOptions；输出为已装入同一进程的节点与话题。
# 执行顺序与边界：C++ 组件由容器持有，无独立 main；注册插件、导出库、安装、加载缺一不可。进程内通信要求相应选项，组件故障仍可影响同一容器。
from launch import LaunchDescription
from launch_ros.actions import ComposableNodeContainer
from launch_ros.descriptions import ComposableNode

# launch 系统调用此工厂获取动作描述；函数本身不是节点的执行回调，参数替换可延后求值。
def generate_launch_description():
    # 描述持有多个 C++ 组件的进程；容器可选多线程，但插件内部仍需正确回调组和共享状态设计。
    container = ComposableNodeContainer(
        name='pair_container', namespace='',
        package='rclcpp_components', executable='component_container_mt',
        output='screen',
        composable_node_descriptions=[
            # 用包名和已注册 plugin 类型创建组件描述；不是直接运行普通可执行文件。
            ComposableNode(package='composition', plugin='composition::Talker',
                           name='talker',
                           # 显式请求进程内通信；两个组件须在同一进程及相容接口下工作，选项不保证所有路径零复制。
                           extra_arguments=[{'use_intra_process_comms': True}]),
            ComposableNode(package='composition', plugin='composition::Listener',
                           name='listener',
                           extra_arguments=[{'use_intra_process_comms': True}]),
        ])
    # 返回 launch 动作集合，由启动系统执行；列表顺序不能作为节点发现/生命周期就绪屏障。
    return LaunchDescription([container])