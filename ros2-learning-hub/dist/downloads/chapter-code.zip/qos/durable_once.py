# 【中文教学注释】 durable_once.py 完整脚本
# 本例作用：QoSProfile 固定三项关键策略；publisher 变量在 spin 期间保持引用。String 是消息而非裸字符串。脚本没有定时器，因此晚加入收到的 configured 来自历史缓存。
# 输入输出：输入为发布/订阅 QoS 策略和消息；输出为端点匹配结果或晚加入者收到的缓存状态。
# 执行顺序与边界：depth 是历史条数；reliable/best_effort 与 transient_local/volatile 有请求-提供兼容约束。发布一次后仍须保留端点，缓存并不等于磁盘永久保存。
import rclpy
from rclpy.node import Node
from rclpy.qos import QoSProfile, ReliabilityPolicy, DurabilityPolicy
from std_msgs.msg import String

# 程序入口按本章顺序组织资源；本例仅在 __main__ 下运行，import 时不应启动节点或连接硬件。
def main():
    # 初始化当前进程的 ROS 上下文并解析传入 ROS 参数；在创建节点/端点之前调用。
    rclpy.init()
    # 创建并持有节点对象；本进程退出前应显式 destroy_node，创建节点本身不会自动处理回调。
    node = Node('durable_once')
    # 构造 QoS：depth 是样本条数；可靠性和持久性须与对端兼容，缓存深度不决定发布频率。
    qos = QoSProfile(depth=1, reliability=ReliabilityPolicy.RELIABLE,
                     # 保留发布者存活期间的历史样本供相容晚加入订阅者接收；仍受深度/资源约束，不是永久存储。
                     durability=DurabilityPolicy.TRANSIENT_LOCAL)
    # 创建指定消息类型和话题的发布端并持久保存；整数 QoS 是 KeepLast 历史深度，不是 Hz，真正发送由 publish 调用决定。
    publisher = node.create_publisher(String, '/last_state', qos)
    # 提交已填好的消息给 ROS 发布端；这不是业务处理完成确认，端到端接收仍取决于发现、类型、QoS 和执行器。
    publisher.publish(String(data='configured'))
    try:
        # 进入执行器事件循环，定时器、订阅、服务和 Future 回调在这里才被推进；通常阻塞到中断或上下文关闭。
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        # 显式释放节点所属端点与定时器；应在相关执行器不再访问节点后执行。
        node.destroy_node()
        # 检查 ROS 上下文仍有效，避免退出流程重复 shutdown；它不表示节点业务健康。
        if rclpy.ok():
            # 关闭本进程 ROS 上下文；先停止执行器、销毁端点/节点，再在上下文仍有效时调用。
            rclpy.shutdown()

if __name__ == '__main__':
    main()