# 【中文教学注释】 rl_gain_search.py
# 本例作用：完整、可运行的原创参数搜索实验。不是 PPO、SAC 或 Isaac Lab 的实现，也不代表任何机器人性能结果。
# 输入输出：输入为候选增益、随机种子和教学动力学参数；输出为训练收益、选定增益和留出条件结果。
# 执行顺序与边界：模型约定位置 m、速度 m/s、质量 kg、积分步长 0.05 s；力限制 ±1 N。奖励是选定标度的教学目标，不是物理能量，也未连接机器人。
"""A tiny policy-search experiment; standard library only, no robot connection."""
import json
import random

# 按seed建立独立随机初值，以0.05s步长积分给定增益/质量的教学模型，返回累计收益与终态绝对位置误差。
def rollout(gain, seed, mass=1.0, steps=120):
    # 使用本次rollout独立随机种子，避免候选之间不受控地共享随机状态；训练种子与留出种子分开。
    rng = random.Random(seed)
    position, velocity = rng.uniform(-2.0, 2.0), 0.0
    reward = 0.0
    for _ in range(steps):
        # PD型教学策略按位置/速度反馈产生力，限幅±1N；gain对应位置反馈，0.8为所选速度反馈系数，未包含真实执行器与接触约束。
        force = max(-1.0, min(1.0, -gain * position - 0.8 * velocity))
        # 按显式离散更新速度：force/mass为m/s²，加上所选线性阻尼后乘0.05s；mass必须为正，当前实验使用预设正质量。
        velocity += (force / mass - 0.1 * velocity) * 0.05
        # 用更新后的速度积分位置，步长0.05s；这是所选离散教学模型，不能当作连续动力学的精确解。
        position += velocity * 0.05
        # 累积位置误差与控制幅度的加权惩罚；权重含人为尺度选择，不把两项当作同一物理能量。
        reward -= position ** 2 + 0.01 * force ** 2
    return reward, abs(position)

# 对给定seed集合复用相同增益评估；seed集合必须非空，留出种子和质量改变用于检查过拟合。
def evaluate(gain, seeds, mass=1.0):
    results = [rollout(gain, seed, mass) for seed in seeds]
    return {"gain": gain, "mass": mass,
            "mean_return": sum(x[0] for x in results) / len(results),
            "mean_final_error": sum(x[1] for x in results) / len(results)}

# 程序入口按本章顺序组织资源；本例仅在 __main__ 下运行，import 时不应启动节点或连接硬件。
def main():
    candidates = [evaluate(g, range(5)) for g in (0.0, 0.25, 0.5, 1.0, 2.0)]
    best = max(candidates, key=lambda item: item["mean_return"])["gain"]
    print(json.dumps({"training": candidates, "selected_gain": best,
                      "held_out": [evaluate(best, range(100, 110), mass)
                                   for mass in (0.7, 1.0, 1.5)]}, indent=2))

if __name__ == "__main__":
    main()
