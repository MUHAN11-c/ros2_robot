def aerial_lab():
    """检查 ENU/NED、FLU/FRD 的向量变换与理想四旋翼悬停推力。"""
    import math

    def enu_to_ned(v):
        # 输入/输出都是同一种物理量；位置用 m，速度用 m/s，不能混用。
        east,north,up = v
        return north,east,-up

    def flu_to_frd(v):
        forward,left,up = v
        return forward,-left,-up

    vector_enu_m = (1.0,2.0,3.0)
    vector_ned_m = enu_to_ned(vector_enu_m)
    assert vector_ned_m == (2.0,1.0,-3.0)
    assert enu_to_ned(vector_ned_m) == vector_enu_m
    assert flu_to_frd(flu_to_frd(vector_enu_m)) == vector_enu_m
    assert math.isclose(sum(v*v for v in vector_enu_m),sum(v*v for v in vector_ned_m))
    # 理想水平悬停：总推力为 mg；此处 N 不能直接写入归一化推力消息。
    mass_kg,g_m_s2 = 1.5,9.81
    total_thrust_n = mass_kg*g_m_s2
    thrust_per_rotor_n = total_thrust_n/4
    assert math.isclose(4*thrust_per_rotor_n/mass_kg-g_m_s2,0.0,abs_tol=1e-12)
    result = {"ENU位置_m": vector_enu_m, "NED位置_m": vector_ned_m,
              "总悬停推力_N": total_thrust_n, "每旋翼推力_N": thrust_per_rotor_n}
    print("无人机坐标与推力", result)
    return result

if __name__ == "__main__":
    aerial_lab()
