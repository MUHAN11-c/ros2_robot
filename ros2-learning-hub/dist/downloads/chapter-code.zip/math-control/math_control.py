#!/usr/bin/env python3
"""输入：固定离散控制模型和 PD 模型；输出：稳定/失稳反例、限幅响应与能量检查。"""

def run():
    import math

    def discrete_integrator(initial_error_m, gain_per_s, period_s, steps, limit_m_s=None):
        if gain_per_s <= 0.0 or period_s <= 0.0:
            raise ValueError('增益和采样周期必须为正')
        error = initial_error_m
        history = [error]
        for _ in range(steps):
            velocity = -gain_per_s*error  # P 控制输出的单位为 m/s。
            if limit_m_s is not None:
                velocity = max(-limit_m_s, min(limit_m_s, velocity))
            error += period_s*velocity  # 本例被控对象是理想位置积分器。
            history.append(error)
        return history

    # 离散闭环乘子为 1-k*dt；连续时间 k>0 并不足以保证离散实现稳定。
    stable = discrete_integrator(1.0, 2.0, 0.1, 100)
    unstable = discrete_integrator(1.0, 3.0, 1.0, 10)
    assert abs(stable[-1]) < 1e-8
    assert abs(unstable[-1]) == 1024.0
    saturated = discrete_integrator(2.0, 2.0, 0.1, 200, limit_m_s=0.3)
    assert abs(saturated[-1]) < 1e-8
    assert max(abs(b-a) for a, b in zip(saturated, saturated[1:])) <= 0.030000000001

    # 力控质点：m*xddot=u-c*xdot；u=-kp*x-kd*xdot，目标位置固定为 0m。
    mass, physical_damping = 2.0, 0.4  # kg、N*s/m。
    kp, kd = 4.0, 3.6  # N/m、N*s/m；闭环总阻尼为 4.0 N*s/m。
    dt = 0.005
    state = [1.0, 0.0]  # [位置误差(m), 速度(m/s)]。

    def derivative(value):
        error, speed = value
        return [speed, (-kp*error-(physical_damping+kd)*speed)/mass]

    def lyapunov(value):
        error, speed = value
        return 0.5*kp*error*error+0.5*mass*speed*speed  # J。

    previous_energy = lyapunov(state)
    for _ in range(3000):
        # RK4 仅用于近似连续对象，不能据此证明真实机器人闭环稳定。
        k1 = derivative(state)
        k2 = derivative([x+dt*k/2 for x, k in zip(state, k1)])
        k3 = derivative([x+dt*k/2 for x, k in zip(state, k2)])
        k4 = derivative([x+dt*k for x, k in zip(state, k3)])
        state = [x+dt*(a+2*b+2*c+d)/6 for x, a, b, c, d in zip(state, k1, k2, k3, k4)]
        current_energy = lyapunov(state)
        assert current_energy <= previous_energy+1e-10
        previous_energy = current_energy
    assert abs(state[0]) < 1e-5 and abs(state[1]) < 1e-5
    damping_ratio = (physical_damping+kd)/(2*math.sqrt(mass*kp))
    assert math.isclose(damping_ratio, 1/math.sqrt(2), abs_tol=1e-12)
    result = {'stable_error_m': stable[-1], 'unstable_error_m': unstable[-1],
              'saturated_error_m': saturated[-1], 'PD_final_state': state,
              'PD_damping_ratio': damping_ratio}
    print('反馈控制实验通过：', result)
    return result

if __name__ == '__main__':
    run()
