def legged_lab():
    """LIPM 精确解：展示 ZMP 在支撑区内仍不足以保证无需迈步地停止。"""
    import math

    # 输入：平地、恒质心高度、无角动量变化、无外扰的一维简化模型。
    # c、z、h 单位 m；v 单位 m/s；g 单位 m/s²；omega 单位 s^-1。
    h, g, c0, v0, z, half_support = 0.8, 9.81, 0.03, 0.35, 0.0, 0.10
    omega = math.sqrt(g/h)
    capture = c0+v0/omega

    def exact(t_s, initial_v, zmp):
        c = zmp+(c0-zmp)*math.cosh(omega*t_s)+initial_v/omega*math.sinh(omega*t_s)
        v = omega*(c0-zmp)*math.sinh(omega*t_s)+initial_v*math.cosh(omega*t_s)
        return c,v

    c_half,v_half = exact(0.5,v0,z)
    assert -half_support <= z <= half_support
    assert capture > half_support and c_half > half_support
    # 对较小的初速度，选择可达捕获点作为恒定 ZMP，可消除发散分量。
    slow_v = 0.10
    feasible_capture = c0+slow_v/omega
    assert abs(feasible_capture) < half_support
    c_slow,v_slow = exact(1.0,slow_v,feasible_capture)
    assert abs(v_slow) < slow_v
    assert math.isclose(c_slow+v_slow/omega,feasible_capture,abs_tol=1e-12)
    result = {"快运动捕获点_m": capture, "固定ZMP半秒后质心_m": c_half,
              "慢运动捕获点_m": feasible_capture, "慢运动一秒后速度_m_s": v_slow}
    print("足式简化模型", result)
    return result

if __name__ == "__main__":
    legged_lab()
