#!/usr/bin/env python3
"""输入：米和弧度表示的位姿；输出：变换、逆变换与四元数一致性检查。"""

def run():
    import math

    def rotate2(angle_rad, point_m):
        # 列向量约定：R_AB 将 B 系分量转换为 A 系分量。
        c, s = math.cos(angle_rad), math.sin(angle_rad)
        x, y = point_m
        return [c * x - s * y, s * x + c * y]

    def apply2(angle_rad, translation_m, point_m):
        return [a + b for a, b in zip(rotate2(angle_rad, point_m), translation_m)]

    def quaternion_product(left, right):
        # 所有参数与返回值都严格采用 ROS 消息的 (x,y,z,w) 次序。
        # 乘法不交换；先应用 right，再应用 left 对应 left*right。
        x, y, z, w = left
        a, b, c, d = right
        return [w*a + x*d + y*c - z*b, w*b - x*c + y*d + z*a,
                w*c + x*b - y*a + z*d, w*d - x*a - y*b - z*c]

    # 平面实验：B 原点在 A 中为 (1,2)m，B 相对 A 绕 z 正转 90 度。
    angle = math.pi / 2.0
    translation = [1.0, 2.0]
    point_b = [2.0, 0.0]
    point_a = apply2(angle, translation, point_b)
    assert all(math.isclose(a, b, abs_tol=1e-12) for a, b in zip(point_a, [1.0, 4.0]))
    inverse_translation = rotate2(-angle, [-x for x in translation])
    recovered = apply2(-angle, inverse_translation, point_a)
    assert max(abs(a-b) for a, b in zip(recovered, point_b)) < 1e-12
    # 串联 A<-B<-C：不能直接把不同坐标系中的平移向量相加。
    t_bc = [0.5, 0.0]
    t_ac = apply2(angle, translation, t_bc)
    direct = apply2(angle + 0.2, t_ac, [0.3, -0.1])
    chained = apply2(angle, translation, apply2(0.2, t_bc, [0.3, -0.1]))
    assert max(abs(a-b) for a, b in zip(direct, chained)) < 1e-12

    # Rodrigues：本例单位旋转轴是 z，K=[u]_x；验证正交性与指定点的旋转。
    unit_axis = [0.0, 0.0, 1.0]
    k = [[0.0, -unit_axis[2], unit_axis[1]],
         [unit_axis[2], 0.0, -unit_axis[0]], [-unit_axis[1], unit_axis[0], 0.0]]
    k2 = [[sum(k[i][n] * k[n][j] for n in range(3)) for j in range(3)] for i in range(3)]
    rotation = [[float(i == j) + math.sin(angle)*k[i][j] + (1-math.cos(angle))*k2[i][j]
                 for j in range(3)] for i in range(3)]
    for i in range(3):
        for j in range(3):
            assert abs(sum(rotation[n][i]*rotation[n][j] for n in range(3)) - float(i == j)) < 1e-12
    assert abs(rotation[0][0]) < 1e-12 and math.isclose(rotation[1][0], 1.0, abs_tol=1e-12)

    # 单位四元数与其共轭相乘得到恒等旋转；零四元数不允许归一化。
    q = [0.0, 0.0, math.sin(angle/2.0), math.cos(angle/2.0)]
    assert math.isclose(sum(x*x for x in q), 1.0, abs_tol=1e-12)
    inverse_q = [-q[0], -q[1], -q[2], q[3]]
    identity_q = quaternion_product(q, inverse_q)
    assert max(abs(a-b) for a, b in zip(identity_q, [0, 0, 0, 1])) < 1e-12
    # q 与 -q 的二次旋转表达式一致；符号不同不代表姿态突变。
    yaw_cos_q = 1.0 - 2.0 * q[2]**2
    yaw_cos_minus_q = 1.0 - 2.0 * (-q[2])**2
    assert yaw_cos_q == yaw_cos_minus_q
    # 用纯向量四元数再次计算旋转，与 Rodrigues 的第一列独立对照。
    rotated_vector = quaternion_product(quaternion_product(q, [1.0, 0.0, 0.0, 0.0]), inverse_q)[:3]
    negative_q = [-value for value in q]
    negative_inverse = [-value for value in inverse_q]
    rotated_negative = quaternion_product(
        quaternion_product(negative_q, [1.0, 0.0, 0.0, 0.0]), negative_inverse)[:3]
    assert max(abs(rotated_vector[i]-rotation[i][0]) for i in range(3)) < 1e-12
    assert max(abs(a-b) for a, b in zip(rotated_vector, rotated_negative)) < 1e-12
    result = {'point_in_A_m': point_a, 'recovered_in_B_m': recovered, 'quaternion_xyzw': q}
    print('刚体变换实验通过：', result)
    return result

if __name__ == '__main__':
    run()
