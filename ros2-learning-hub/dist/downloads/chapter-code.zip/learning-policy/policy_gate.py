# 【中文教学注释】 policy_gate.py
# 本例作用：完整标准库实验。以六关节位置目标演示合同检查；不是机器人控制器，也不是安全认证组件。
# 输入输出：输入为6关节位置候选、上一目标、数据年龄和控制周期；输出为限幅/限速位置或 None。
# 执行顺序与边界：关节位置 rad、年龄/dt s、limit rad/s；拒绝非有限数，数据年龄上限0.1s。None 需调用者选择已验证停止/保持策略，限幅并不保证无碰撞。
"""Demonstrate timestamp/dimension/finite/rate checks for a six-joint policy."""
import math

# 输入6关节位置(rad)、上一目标(rad)、年龄(s)、dt(s)和速率上限(rad/s)；返回位置列表或陈旧数据标记None。
def gate(candidate, previous, age_seconds, dt, limit=0.5):
    # These are position targets in radians, not torques or velocities.
    if len(candidate) != 6 or len(previous) != 6:
        raise ValueError("expected six joints in the agreed order")
    if not all(math.isfinite(x) for x in (*candidate, *previous, age_seconds, dt, limit)):
        raise ValueError("non-finite input")
    if dt <= 0 or limit <= 0:
        raise ValueError("invalid control interval or rate limit")
    if age_seconds < 0 or age_seconds > 0.1:
        # 明确向调用者表示数据过期；调用者应进入已验证的停止/保持流程，不能把None当成零力矩。
        return None  # Caller must select its independently verified stop/hold mode.
    output = []
    for target, last in zip(candidate, previous):
        # 先把候选位置限制到[-1,1]rad；这是教学位置范围，不能替代实际每个关节的硬限位或碰撞检查。
        bounded = max(-1.0, min(1.0, target))
        # 把单步位置变化限制为±limit×dt(rad)，保持输出维度和既定关节顺序；限速不保证轨迹连续加速度或安全避障。
        output.append(last + max(-limit * dt, min(limit * dt, bounded - last)))
    return output

# 程序入口按本章顺序组织资源；本例仅在 __main__ 下运行，import 时不应启动节点或连接硬件。
def main():
    print("ACCEPTED", gate([0.5] * 6, [0.0] * 6, 0.02, 0.02))
    print("STALE", gate([0.5] * 6, [0.0] * 6, 0.3, 0.02))
    try:
        gate([float("nan")] * 6, [0.0] * 6, 0.02, 0.02)
    except ValueError as error:
        print("REJECTED", error)

if __name__ == "__main__":
    main()
