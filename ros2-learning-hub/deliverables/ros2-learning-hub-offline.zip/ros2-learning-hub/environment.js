/* 便携阅读包：第三方原始资料需另外复制。 */
window.ROS2Environment = {workspace:false};
