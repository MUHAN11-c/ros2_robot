/* 仅列实际存在的浏览器截图；测试结论另见validation/browser-report.json。 */
window.NarukamiReviewEvidence = {
  "screenshots": [
    {
      "file": "screenshots/desktop-light.png",
      "title": "桌面1440px · 樱粉浅色首页",
      "sha256": "215f355e98e1eb3cba804f5e7879557e0723ad445708b4e5815a4d8e6e838fbd"
    },
    {
      "file": "screenshots/desktop-dark.png",
      "title": "桌面1440px · 夜紫深色首页",
      "sha256": "b199c08a04deb83a5587faa3cf89393dcd306bbe624ccecf8fa2bfeae50abd0b"
    },
    {
      "file": "screenshots/chapter-light.png",
      "title": "章节阅读 · 正文与图解",
      "sha256": "271751099867dc568d23f12d1d48227f7233baa2622923dbfa02c1e60765fe24"
    },
    {
      "file": "screenshots/editor-desktop.png",
      "title": "章节编辑 · 原排版直接修改",
      "sha256": "770cf06fe528b3b2c290926f6e423d75c311810f1fc0ac30c21a208753ac9315"
    },
    {
      "file": "screenshots/editor-mobile.png",
      "title": "手机390px · 深色原排版编辑",
      "sha256": "8be3cf184df4d26fa03c119ea99738ea4b09abf0f852177bf0165a699e843e52"
    },
    {
      "file": "screenshots/note-drawer.png",
      "title": "章节笔记 · 编辑抽屉",
      "sha256": "ab7ebf79766e6f585b66d388310b4a84c9380d4856d9552743306d4cb2ba53fa"
    },
    {
      "file": "screenshots/search-results.png",
      "title": "全文搜索 · 命中与定位",
      "sha256": "04ed3b48c6b09efe6d1e1114d6633c5e176ad29c950419d101b87d6978248b80"
    },
    {
      "file": "screenshots/search-empty.png",
      "title": "全文搜索 · 空态",
      "sha256": "267333a4bd267c67a5d9a79398e2d8c7d01dc2f2fd5d7efbc0e7cd550a205380"
    },
    {
      "file": "screenshots/lab-wide.png",
      "title": "坐标变换 · 宽屏实验",
      "sha256": "8587b22a57a2a36731e2d1098afe5b223f78856f35f34b3774f469fe571c37d1"
    },
    {
      "file": "screenshots/model-lab.png",
      "title": "机器人几何模型 · 交互",
      "sha256": "c322185aaa60096980f2ddc2d1012e1534bbca390fb9444f3bded6c470ff4ddd"
    },
    {
      "file": "screenshots/gallery.png",
      "title": "紫樱素材 · 来源审查画廊",
      "sha256": "3e0437c1cbed6c83f93b5e2737f42c4a88d7937086f74780ca4e81bb8e8d843f"
    },
    {
      "file": "screenshots/mobile-390.png",
      "title": "手机390px · 樱粉浅色",
      "sha256": "e354a75968d167664dd7bc5471a1652590297ad9c78c597d72f1962c190bee74"
    },
    {
      "file": "screenshots/mobile-320.png",
      "title": "手机320px · 樱粉浅色",
      "sha256": "ff8ef3b5d9496ca0e4055624fae4def5fa54439786638dc0275c271ebad3b22a"
    },
    {
      "file": "screenshots/mobile-dark.png",
      "title": "手机390px · 夜紫深色",
      "sha256": "09907995bd93cf8694c334d6ae7b6fabe8c4efc3630799f1cfa186277f07c15e"
    },
    {
      "file": "screenshots/mobile-note.png",
      "title": "手机390px · 章节笔记",
      "sha256": "5ab6f907c40116cadd1ede6677964f0eb53cdecf68f91f93532593f118833e1f"
    }
  ]
};
